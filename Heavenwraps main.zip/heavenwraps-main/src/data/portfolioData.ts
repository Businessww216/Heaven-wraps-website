
import { createImageUrl } from '@/utils/imageUtils';

export const gerapteKistenExamples = [
  {
    id: 1,
    title: "Ivoorlicht",
    description: "Een serene uitvaartkist in zacht ivoor die zachtheid, puurheid en tijdloze eenvoud uitstraalt.",
    image: createImageUrl("/lovable-uploads/1a11d74d-aefc-47ee-9709-34e5c8bc3a08.png"),
    price: "€795,- excl btw",
    type: "Standaard wrap",
    isComingSoon: false
  },
  {
    id: 2,
    title: "Sage green Sereniteit",
    description: "Een rustgevende, grijsgroene uitvaartkist die natuurlijke elegantie en zachte waardigheid uitstraalt.",
    image: createImageUrl("/lovable-uploads/0b726d4e-26cb-4cdd-8dd5-f2ad676b9beb.png"),
    price: "€795,- excl btw",
    type: "Standaard wrap",
    isComingSoon: false
  },
  {
    id: 3,
    title: "Zwart Zwijgend",
    description: "Een stijlvolle uitvaartkist in diep marineblauw die kracht, rust en ingetogen klasse samenbrengt.",
    image: createImageUrl("/lovable-uploads/7069278a-da46-433c-9df8-c1b47de5f466.png"),
    price: "€795,- excl btw",
    type: "Standaard wrap",
    isComingSoon: false
  },
  {
    id: 4,
    title: "Zonneveld",
    description: "Een levendige uitvaartkist vol zonnebloemen, voor een afscheid dat straalt van liefde, natuur en herinnering.",
    image: createImageUrl("/lovable-uploads/60fc2c64-4983-43e9-9b95-6471e4d7b530.png"),
    price: "€795,- excl btw",
    type: "Standaard wrap",
    isComingSoon: true
  },
  {
    id: 5,
    title: "Al-Noor",
    description: "Een elegante ivoorkleurige uitvaartkist met gouden moskee en kalligrafie, ontworpen voor een sereen en respectvol islamitisch afscheid.",
    image: createImageUrl("/lovable-uploads/29f422c9-30e5-421f-9d2d-8cfbf7c5b457.png"),
    price: "€795,- excl btw",
    type: "Standaard wrap",
    isComingSoon: true
  },
  {
    id: 6,
    title: "Voor Altijd Ajax",
    description: "Een opvallende uitvaartkist in Ajax-stijl voor de ware Ajacied die tot het einde rood-wit blijft.",
    image: createImageUrl("/lovable-uploads/ff43ae34-0d13-4c90-b3b6-49d16d98cb51.png"),
    price: "€795,- excl btw",
    type: "Standaard wrap",
    isComingSoon: true
  }
];
