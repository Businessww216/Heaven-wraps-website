
import { Square, Diamond, TreeDeciduous } from 'lucide-react';

export interface AssortmentItem {
  id: number;
  title: string;
  description: string;
  image: string;
  type: string;
  price: string;
}

export interface CategoryConfig {
  value: string;
  label: string;
  icon: typeof Square;
}

export const assortmentItems: Record<string, AssortmentItem[]> = {
  'basis': [
    {
      id: 1,
      title: "Eenvoudige vurenhouten kist",
      description: "Rustige, pure kist van naturel vurenhout. Een ingetogen laatste rustplaats die tijdloosheid en eenvoud uitstraalt.",
      image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=800&q=80",
      type: "Basis",
      price: "€ 450,-",
    },
    {
      id: 2,
      title: "Onbehandelde populieren kist",
      description: "Licht en natuurlijk populierenhout; voelt warm aan door zijn zachtheid en neutrale uitstraling.",
      image: "/lovable-uploads/67931f76-bfb3-4389-b60e-1c5a52761250.png",
      type: "Basis",
      price: "€ 495,-",
    },
    {
      id: 3,
      title: "Grenen kist met touwgrepen",
      description: "Authentiek grenenhout, afgewerkt met natuurlijke touwgrepen. Stoer, natuurlijk en puur.",
      image: "/lovable-uploads/c9285890-002f-4b7f-91c4-54d22cec88bc.png",
      type: "Basis",
      price: "€ 525,-",
    },
  ],
  'duurzaam': [
    {
      id: 5,
      title: "Ecologische vurenhouten kist",
      description: "Gemaakt van FSC-gecertificeerd vurenhout. Een milieubewuste keuze; liefdevol voor zowel mens als natuur.",
      image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=800&q=80",
      type: "Duurzaam",
      price: "€ 675,-",
    },
    {
      id: 6,
      title: "Bamboe kist",
      description: "Lichtgewicht en volledig biologisch afbreekbaar. Natuurlijk gevlochten bamboe, symbolisch voor verbondenheid.",
      image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
      type: "Duurzaam",
      price: "€ 695,-",
    },
    {
      id: 7,
      title: "Kartonnen kist",
      description: "Sterk en verrassend stijlvol. Karton als bewuste, moderne keuze met een vriendelijke uitstraling.",
      image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=800&q=80",
      type: "Duurzaam",
      price: "€ 395,-",
    },
  ],
  'design': [
    {
      id: 9,
      title: "Strak modern uitvaartkist",
      description: "Een minimalistisch ontwerp in matwit, modern en stijlvol. Zorgt voor rust en elegantie tijdens het afscheid.",
      image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=800&q=80",
      type: "Design",
      price: "€ 795,-",
    },
    {
      id: 10,
      title: "Zwart minimalistisch design",
      description: "Stoer en eigentijds. Zwart met subtiele details voor een krachtige en persoonlijke herinnering.",
      image: "https://images.unsplash.com/photo-1508919801845-fc2ae1bc81b7?auto=format&fit=crop&w=800&q=80",
      type: "Design",
      price: "€ 925,-",
    },
    {
      id: 11,
      title: "Massieve eikenhouten kist",
      description: "Robuuste, zware eiken kist met natuurlijke nerven. Voor een waardevol en klassiek afscheid.",
      image: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?auto=format&fit=crop&w=800&q=80",
      type: "Design",
      price: "€ 1175,-",
    },
  ],
  'natuur': [
    {
      id: 17,
      title: "Wilgenteen kist",
      description: "Met liefde gevlochten van wilgentenen. Zacht, warm en geheel natuurlijk; passend bij elke ingetogen uitvaart.",
      image: "https://images.unsplash.com/photo-1523712999610-f77fbcfc3843?auto=format&fit=crop&w=800&q=80",
      type: "Natuur",
      price: "€ 975,-",
    },
    {
      id: 18,
      title: "Rieten kist",
      description: "Handgevlochten riet. Door het zachte materiaal en natuurlijke tinten wordt elk afscheid bijzonder en huiselijk.",
      image: "https://images.unsplash.com/photo-1472396961693-142e6e269027?auto=format&fit=crop&w=800&q=80",
      type: "Natuur",
      price: "€ 1175,-",
    },
    {
      id: 19,
      title: "Lindehouten kist",
      description: "Gemaakt van licht lindehout uit Nederlandse bossen. Een verfijnde, natuurlijke kist met een vriendelijke uitstraling.",
      image: "https://images.unsplash.com/photo-1501854140801-50d01698950b?auto=format&fit=crop&w=800&q=80",
      type: "Natuur",
      price: "€ 725,-",
    },
  ],
};

export const categoryNames: CategoryConfig[] = [
  { value: "basis", label: "Basis", icon: Square },
  { value: "duurzaam", label: "Duurzaam", icon: Diamond },
  { value: "design", label: "Design", icon: Square },
  { value: "natuur", label: "Natuur", icon: TreeDeciduous },
];
