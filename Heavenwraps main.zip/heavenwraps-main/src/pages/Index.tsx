
import React, { useEffect } from 'react';
import { reloadAllImagesOnPage } from '@/utils/imageUtils';
import { Helmet } from 'react-helmet-async';
import Sidebar from '@/components/Sidebar';
import HeaderContact from '@/components/HeaderContact';
import Hero from '@/components/Hero';
import TestimonialSection from '@/components/TestimonialSection';
import CallToActionSection from '@/components/CallToActionSection';
import Footer from '@/components/Footer';
import VideoSection from '@/components/VideoSection';
import HomeContactForm from '@/components/HomeContactForm';

const Index = () => {
  useEffect(() => {
    // Force reload all images when component mounts
    const timer = setTimeout(() => {
      reloadAllImagesOnPage();
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <Helmet>
        <title>Heaven Wraps - Persoonlijke Uitvaartkisten</title>
        <meta name="description" content="Unieke, persoonlijke uitvaartkisten met professionele wrapping. Maatwerk afscheid met liefde en respect." />
      </Helmet>
      
      <Sidebar />
      <HeaderContact />
      
      <div className="ml-0 md:ml-64">
        <Hero />
        
        <VideoSection />
        <TestimonialSection />
        <HomeContactForm />
        <CallToActionSection />
        <Footer />
      </div>
    </>
  );
};

export default Index;
