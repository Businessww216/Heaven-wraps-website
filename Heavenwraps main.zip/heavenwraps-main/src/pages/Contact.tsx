
import React from 'react';
import Sidebar from '@/components/Sidebar';
import HeaderContact from '@/components/HeaderContact';
import ContactForm from '@/components/ContactForm';
import ContactPageHeader from '@/components/ContactPageHeader';
import ContactInfo from '@/components/ContactInfo';
import ContactFAQ from '@/components/ContactFAQ';
import ContactAutomationSection from '@/components/ContactAutomationSection';
import FadeInSection from '@/components/FadeInSection';
import { Zap } from 'lucide-react';

const Contact = () => {
  return (
    <>
      <Sidebar />
      <HeaderContact />
      
      <div className="ml-0 md:ml-64 page-container relative overflow-hidden">
      {/* Tech Background Effects */}
      <div className="absolute inset-0 tech-grid opacity-5 animate-tech-glow"></div>
      <div className="absolute top-0 left-0 w-64 h-64 bg-gradient-to-br from-funeral-accent/10 to-transparent rounded-full blur-3xl animate-quantum-float"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-tl from-funeral-medium/10 to-transparent rounded-full blur-3xl animate-quantum-float" style={{animationDelay: '3s'}}></div>
      
      {/* Floating Tech Elements */}
      <div className="absolute top-20 left-10 w-2 h-2 bg-funeral-accent/60 rounded-full animate-quantum-float"></div>
      <div className="absolute top-40 right-20 w-1.5 h-1.5 bg-funeral-medium/70 rounded-full animate-pulse-gentle" style={{animationDelay: '1s'}}></div>
      <div className="absolute bottom-32 left-16 w-1 h-1 bg-funeral-sandstone/80 rounded-full animate-tech-glow" style={{animationDelay: '2s'}}></div>

      <div className="container mx-auto relative z-10">
        <ContactPageHeader />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 my-16">
          <FadeInSection delay={200}>
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-funeral-accent to-funeral-medium flex items-center justify-center animate-quantum-float">
                <Zap className="text-funeral-dark" size={24}/>
              </div>
              <h2 className="text-2xl md:text-3xl font-heading font-semibold text-funeral-dark">Neem contact op</h2>
            </div>
            <ContactForm />
          </FadeInSection>

          <FadeInSection delay={500}>
            <div className="space-y-8">
              <ContactInfo />
              <ContactFAQ />
            </div>
          </FadeInSection>
        </div>

        <ContactAutomationSection />
      </div>
      </div>
    </>
  );
};

export default Contact;
