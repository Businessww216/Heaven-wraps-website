
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-funeral-offwhite">
      <div className="text-center p-8">
        <h1 className="text-4xl font-serif font-medium mb-4 text-funeral-black">404</h1>
        <p className="text-xl text-funeral-text mb-6">De pagina die u zoekt bestaat niet.</p>
        <Button asChild className="bg-funeral-sandstone hover:bg-funeral-sandstone/80 text-funeral-black">
          <Link to="/">Terug naar Home</Link>
        </Button>
      </div>
    </div>
  );
};

export default NotFound;
