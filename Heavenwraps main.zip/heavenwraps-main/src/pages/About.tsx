
import React from 'react';
import { Helmet } from 'react-helmet-async';
import Sidebar from '@/components/Sidebar';
import HeaderContact from '@/components/HeaderContact';
import HeroAbout from '@/components/HeroAbout';
import Footer from '@/components/Footer';
import ValueCard from '@/components/ValueCard';


const About = () => {
  return (
    <>
      <Helmet>
        <title>Over Ons - Heaven Wraps</title>
        <meta name="description" content="Leer meer over Heaven Wraps en onze missie om persoonlijke, respectvolle uitvaartkisten te maken." />
      </Helmet>
      
      <Sidebar />
      <HeaderContact />
      
      <div className="ml-0 md:ml-64">
        <HeroAbout />
        
        <section className="page-container">
          <div className="max-w-4xl mx-auto">
            <h2 className="page-title text-center">Onze Waarden</h2>
            <div className="grid md:grid-cols-2 gap-8 mb-16">
              <ValueCard
                icon="respect"
                title="Respect & Waardigheid"
                description="Elk project wordt uitgevoerd met de grootste zorg en respect voor uw dierbare en uw familie."
              />
              <ValueCard
                icon="aandacht"
                title="Persoonlijke Benadering"
                description="Wij luisteren naar uw verhaal en wensen om een uniek en betekenisvol ontwerp te creëren."
              />
              <ValueCard
                icon="kwaliteit"
                title="Vakmanschap"
                description="Jaren van ervaring in design en wrapping zorgen voor een professioneel eindresultaat."
              />
              <ValueCard
                icon="duurzaamheid"
                title="Betrouwbaarheid"
                description="Op tijd leveren is essentieel in onze branche. U kunt op ons rekenen wanneer het nodig is."
              />
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default About;
