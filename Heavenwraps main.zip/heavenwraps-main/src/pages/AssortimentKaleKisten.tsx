
import React from 'react';
import Sidebar from '@/components/Sidebar';
import HeaderContact from '@/components/HeaderContact';
import FadeInSection from "@/components/FadeInSection";
import HeroServices from "@/components/HeroServices";
import TechParticles from '@/components/TechParticles';
import AssortimentTabs from '@/components/AssortimentTabs';
import TestimonialSection from '@/components/TestimonialSection';
import CallToActionSection from '@/components/CallToActionSection';

const AssortimentKaleKisten = () => {
  return (
    <>
      <Sidebar />
      <HeaderContact />
      
      <div className="ml-0 md:ml-64 min-h-screen relative overflow-hidden tech-grid">
      {/* Futuristic Background Effects */}
      <TechParticles />
      
      {/* Quantum Floating Nodes */}
      <div className="fixed top-16 left-12 w-2 h-2 bg-funeral-medium/40 rounded-full animate-quantum-float z-0"></div>
      <div className="fixed top-1/4 right-16 w-1 h-1 bg-funeral-accent/60 rounded-full animate-quantum-float z-0" style={{animationDelay: '2s'}}></div>
      <div className="fixed bottom-1/3 left-1/5 w-1.5 h-1.5 bg-funeral-dark/30 rounded-full animate-quantum-float z-0" style={{animationDelay: '4s'}}></div>
      
      {/* Hero section voor visuele entree */}
      <HeroServices />
      
      <div className="page-container relative z-10">
        <div className="container mx-auto px-4">
          <FadeInSection delay={150}>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-heading font-medium text-center mb-6 md:mb-8 text-funeral-black relative">
              <span className="cyberpunk-text">Assortiment kale kisten</span>
              {/* Chrome Shine Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform skew-x-12 opacity-0 hover:opacity-100 hover:animate-chrome-shine"></div>
            </h1>
          </FadeInSection>
          
          <FadeInSection delay={300}>
            <p className="text-lg md:text-xl lg:text-2xl text-funeral-text text-center max-w-4xl mx-auto mb-8 md:mb-12 leading-relaxed animate-neon-pulse">
              Maak kennis met ons assortiment onbewerkte en basic uitvaartkisten. 
              Ieder model is zorgvuldig geselecteerd en voldoet aan de hoogste maatstaven van kwaliteit.
            </p>
          </FadeInSection>
          
          <FadeInSection delay={400}>
            <AssortimentTabs />
          </FadeInSection>
          
          <FadeInSection delay={500}>
            <TestimonialSection />
          </FadeInSection>
          
          <FadeInSection delay={700}>
            <CallToActionSection />
          </FadeInSection>
        </div>
      </div>
      
      {/* Matrix Connection Lines */}
      <svg className="fixed inset-0 w-full h-full pointer-events-none opacity-10 z-0">
        <defs>
          <pattern id="matrix-lines" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
            <path d="M0,50 Q50,0 100,50" stroke="url(#matrix-gradient)" strokeWidth="0.5" fill="none"/>
          </pattern>
          <linearGradient id="matrix-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="transparent"/>
            <stop offset="50%" stopColor="#E6DED1"/>
            <stop offset="100%" stopColor="transparent"/>
          </linearGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#matrix-lines)"/>
      </svg>
      </div>
    </>
  );
};

export default AssortimentKaleKisten;
