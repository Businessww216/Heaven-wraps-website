import React from 'react';
import Sidebar from '@/components/Sidebar';
import HeaderContact from '@/components/HeaderContact';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AnimatedServiceCard from '@/components/AnimatedServiceCard';
import FadeInSection from '@/components/FadeInSection';
import HeroPortfolio from "@/components/HeroPortfolio";
import { Square, Diamond, Image, TreeDeciduous } from 'lucide-react';

const portfolioItems = {
  'effen-kleuren': [
    {
      id: 1,
      title: "Zwarte FullWrap",
      description: "Volledige kist in stijlvol matzwart gewrapt. Rustige, moderne uitstraling.",
      image: "https://images.unsplash.com/photo-1482881497185-d4a9ddbe4151?auto=format&fit=crop&w=800&q=80",
      type: "FullWrap",
      price: "€1.295",
    },
    {
      id: 2,
      title: "Witte RandWrap",
      description: "RandWrap in helder wit, voor een rustige, kalme sfeer.",
      image: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?auto=format&fit=crop&w=800&q=80",
      type: "RandWrap",
      price: "€995",
    },
    {
      id: 3,
      title: "Blauwe FullWrap",
      description: "Diep marineblauwe wrap, strak en elegant rondom de hele kist.",
      image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=800&q=80",
      type: "FullWrap",
      price: "€1.295",
    },
    {
      id: 4,
      title: "Bordeaux RandWrap",
      description: "Luxe bordeauxrood gewrapt aan de zijkanten voor warmte en klasse.",
      image: "https://images.unsplash.com/photo-1523712999610-f77fbcfc3843?auto=format&fit=crop&w=800&q=80",
      type: "RandWrap",
      price: "€1.095",
    },
  ],
  'parelmoer': [
    {
      id: 5,
      title: "Wit Parelmoer TopWrap",
      description: "Deksel in zachte, reflecterende parelmoer voor een serene gloed.",
      image: "https://images.unsplash.com/photo-1482938289607-e9573fc25ebb?auto=format&fit=crop&w=800&q=80",
      type: "TopWrap",
      price: "€1.195",
    },
    {
      id: 6,
      title: "Goud Parelmoer RandWrap",
      description: "Opvallende goudkleuring met subtiel parelmoer effect op de randen.",
      image: "https://images.unsplash.com/photo-1500673922987-e212871fec22?auto=format&fit=crop&w=800&q=80",
      type: "RandWrap",
      price: "€1.295",
    },
    {
      id: 7,
      title: "Zilver Parelmoer FullWrap",
      description: "Volledige kist gewrapt in schitterend zilver parelmoer.",
      image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
      type: "FullWrap",
      price: "€1.495",
    },
    {
      id: 8,
      title: "Roze Parelmoer TopWrap",
      description: "Deksel van de kist met zachte roze parelmoer afwerking.",
      image: "https://images.unsplash.com/photo-1501854140801-50d01698950b?auto=format&fit=crop&w=800&q=80",
      type: "TopWrap",
      price: "€1.195",
    },
  ],
  'marmer': [
    {
      id: 9,
      title: "Groen Marmer RandWrap",
      description: "Randen met diepgroene marmer print, voor een luxueuze uitstraling.",
      image: "https://images.unsplash.com/photo-1615729947596-a598e5de0ab3?auto=format&fit=crop&w=800&q=80",
      type: "RandWrap",
      price: "€1.195",
    },
    {
      id: 10,
      title: "Beige Marmer FullWrap",
      description: "Kist volledig in zachtbeige marmerlook gewrapt.",
      image: "https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=crop&w=800&q=80",
      type: "FullWrap",
      price: "€1.395",
    },
    {
      id: 11,
      title: "Zwart Marmer TopWrap",
      description: "Dramatisch zwart marmer op de deksel, modern en krachtig.",
      image: "https://images.unsplash.com/photo-1518005020951-eccb494ad742?auto=format&fit=crop&w=800&q=80",
      type: "TopWrap",
      price: "€1.295",
    },
    {
      id: 12,
      title: "Blauw Marmer FullWrap",
      description: "Volledige kist met koele blauw marmer print.",
      image: "https://images.unsplash.com/photo-1472396961693-142e6e269027?auto=format&fit=crop&w=800&q=80",
      type: "FullWrap",
      price: "€1.395",
    },
  ],
  'foto-collage': [
    {
      id: 13,
      title: "Familie Collage TopWrap",
      description: "Deksel met collage van dierbare familieportretten.",
      image: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?auto=format&fit=crop&w=800&q=80",
      type: "TopWrap",
      price: "€1.295",
    },
    {
      id: 14,
      title: "Hobby’s FullWrap",
      description: "Wrap met afbeeldingen van de hobby’s van de overledene rondom de kist.",
      image: "https://images.unsplash.com/photo-1482881497185-d4a9ddbe4151?auto=format&fit=crop&w=800&q=80",
      type: "FullWrap",
      price: "€1.495",
    },
    {
      id: 15,
      title: "Reisherinneringen Collage",
      description: "TopWrap collage met favoriete reisbestemmingen.",
      image: "https://images.unsplash.com/photo-1482938289607-e9573fc25ebb?auto=format&fit=crop&w=800&q=80",
      type: "TopWrap",
      price: "€1.295",
    },
    {
      id: 16,
      title: "Herinneringen FullWrap",
      description: "Creatieve wrap rondom de kist met belangrijke levensmomenten en foto’s.",
      image: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?auto=format&fit=crop&w=800&q=80",
      type: "FullWrap",
      price: "€1.495",
    },
  ],
  'natuur': [
    {
      id: 17,
      title: "Bloemen FullWrap",
      description: "Kleurige bloemen en veldboeketten rondom, natuurvol en vrolijk.",
      image: "https://images.unsplash.com/photo-1465146344425-f00d5f5c8f07?auto=format&fit=crop&w=800&q=80",
      type: "FullWrap",
      price: "€1.495",
    },
    {
      id: 18,
      title: "Bos RandWrap",
      description: "Groene bosranden op de kist, fris en levendig.",
      image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
      type: "RandWrap",
      price: "€1.195",
    },
    {
      id: 19,
      title: "Zee RandWrap",
      description: "Randen met golvende zee, rustgevend en open.",
      image: "https://images.unsplash.com/photo-1501854140801-50d01698950b?auto=format&fit=crop&w=800&q=80",
      type: "RandWrap",
      price: "€1.095",
    },
    {
      id: 20,
      title: "Bergen TopWrap",
      description: "Prachtig berglandschap op het deksel, symbool voor kracht en eeuwigheid.",
      image: "https://images.unsplash.com/photo-1615729947596-a598e5de0ab3?auto=format&fit=crop&w=800&q=80",
      type: "TopWrap",
      price: "€1.195",
    },
  ],
};

const tabIcons = {
  'effen-kleuren': Square,
  'parelmoer': Diamond,
  'marmer': Square,
  'foto-collage': Image,
  'natuur': TreeDeciduous,
};

const Portfolio = () => {
  return (
    <>
      <Sidebar />
      <HeaderContact />
      
      <div className="ml-0 md:ml-64 page-container">
      <HeroPortfolio />
      <div className="container mx-auto">
        {/* Tab selector with animated icons */}
        <FadeInSection delay={100}>
          <Tabs defaultValue="effen-kleuren" className="w-full my-12">
            <TabsList className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 mb-8 bg-funeral-offwhite">
              {[
                { value: "effen-kleuren", label: "Effen kleuren" },
                { value: "parelmoer", label: "Parelmoer" },
                { value: "marmer", label: "Marmer" },
                { value: "foto-collage", label: "Foto collage" },
                { value: "natuur", label: "Natuur" },
              ].map(({ value, label }) => {
                const Icon = tabIcons[value];
                return (
                  <TabsTrigger
                    key={value}
                    value={value}
                    className="flex flex-col md:flex-row gap-2 items-center
                      transition-all duration-200 group
                      data-[state=active]:bg-funeral-medium/10 data-[state=active]:text-funeral-medium
                    "
                  >
                    <Icon className="h-5 w-5 group-hover:animate-bounce-float transition-transform duration-200" />
                    <span>{label}</span>
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {Object.entries(portfolioItems).map(([category, items]) => (
              <TabsContent key={category} value={category} className="animate-fade-in">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {category === "effen-kleuren"
                    ? Array.from({ length: 12 }).map((_, idx) => (
                        <FadeInSection key={idx} delay={100 + idx * 70}>
                          <AnimatedServiceCard
                            title={`Voorbeeld kist ${idx + 1}`}
                            description="Hier komt later een voorbeeld van een gewrapte kist."
                            price="Prijs volgt"
                            image="https://images.unsplash.com/photo-1482881497185-d4a9ddbe4151?auto=format&fit=crop&w=800&q=80"
                            additionalInfo="Type volgt"
                          />
                        </FadeInSection>
                      ))
                    : items.map((item, idx) => (
                        <FadeInSection key={item.id} delay={100 + idx * 80}>
                          <AnimatedServiceCard
                            title={item.title}
                            description={item.description}
                            price={item.price}
                            image={item.image}
                            additionalInfo={item.type}
                          />
                        </FadeInSection>
                      ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </FadeInSection>

        {/* Testimonials - animated */}
        <FadeInSection delay={150}>
          <div className="bg-funeral-light p-8 rounded-lg my-12">
            <h2 className="text-2xl font-heading mb-4 text-funeral-dark text-center">Wat onze klanten zeggen</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
              {[
                {
                  quote: "De persoonlijke uitvaartkist die Meijerink voor mijn vader heeft gemaakt, was precies wat we wilden. De natuur- en visgerelateerde print was prachtig en betekenisvol.",
                  author: "Familie Jansen"
                },
                {
                  quote: "In een moeilijke tijd hebben zij ons ontzorgd. De kist met foto's van onze moeder bracht troost en maakte de uitvaart nog persoonlijker.",
                  author: "Familie de Boer"
                },
                {
                  quote: "De snelle service en de kwaliteit van het eindresultaat hebben ons positief verrast. Een waardige laatste eer voor onze geliefde.",
                  author: "Familie Visser"
                },
                {
                  quote: "Het ontwerpproces was respectvol en professioneel. De TopWrap met het kunstwerk van mijn man is precies geworden zoals we hoopten.",
                  author: "Familie van Dijk"
                }
              ].map((testimonial, index) => (
                <FadeInSection key={index} delay={170 + index * 100}>
                  <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-lg transition group hover-scale">
                    <div className="text-funeral-medium text-3xl mb-4 group-hover:scale-110 transition-transform duration-200">
                      "
                    </div>
                    <p className="text-funeral-text italic mb-4">{testimonial.quote}</p>
                    <p className="text-funeral-dark font-medium">— {testimonial.author}</p>
                  </div>
                </FadeInSection>
              ))}
            </div>
          </div>
        </FadeInSection>
        {/* Call to action section - animated */}
        <FadeInSection delay={220}>
          <div className="text-center my-12">
            <h2 className="text-2xl font-heading mb-6 text-funeral-dark">Laat u inspireren</h2>
            <p className="text-funeral-text max-w-3xl mx-auto mb-8">
              Deze portfolio is slechts een kleine selectie van wat mogelijk is. Elk ontwerp is uniek 
              en wordt volledig aangepast aan uw wensen en het leven van uw dierbare.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild className="bg-funeral-medium hover:bg-funeral-dark text-funeral-text hover:text-white animate-bounce">
                <Link to="/diensten">Bekijk onze producten</Link>
              </Button>
              <Button asChild variant="outline" className="border border-funeral-medium hover:bg-funeral-light text-funeral-dark">
                <Link to="/contact">Vragen? Bel naar onze nummer</Link>
              </Button>
            </div>
          </div>
        </FadeInSection>
      </div>
      </div>
    </>
  );
};

export default Portfolio;
