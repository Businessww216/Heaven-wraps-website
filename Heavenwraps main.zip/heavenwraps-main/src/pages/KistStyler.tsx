import React, { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import HeaderContact from '@/components/HeaderContact';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Palette, Wand2, Download, Share2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import PromptInput from '@/components/PromptInput';
import KistPreview from '@/components/KistPreview';
import StylerControls from '@/components/StylerControls';
import TechParticles from '@/components/TechParticles';

const KistStyler = () => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [style, setStyle] = useState('classic');
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt vereist",
        description: "Voer een beschrijving in voor uw kist design.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      console.log('Generating kist design with prompt:', prompt, 'and style:', style);
      
      const { data, error } = await supabase.functions.invoke('generate-kist-design', {
        body: {
          prompt: prompt,
          style: style
        }
      });

      if (error) {
        console.error('Supabase function error:', error);
        throw new Error(error.message || 'Er is een fout opgetreden bij het genereren');
      }

      if (data?.error) {
        console.error('API error:', data.error);
        throw new Error(data.error);
      }

      if (data?.imageUrl) {
        setGeneratedImage(data.imageUrl);
        toast({
          title: "Design gegenereerd!",
          description: "Uw kist design is succesvol gegenereerd.",
        });
      } else {
        throw new Error('Geen afbeelding ontvangen van de API');
      }
      
    } catch (error) {
      console.error('Error generating design:', error);
      toast({
        title: "Fout",
        description: error.message || "Er is een fout opgetreden bij het genereren van het design.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Sidebar />
      <HeaderContact />
      
      <div className="ml-0 md:ml-64 min-h-screen bg-funeral-offwhite relative overflow-hidden">
      {/* Tech Particles Background */}
      <TechParticles />
      
      {/* Ambient Tech Background */}
      <div className="absolute inset-0 tech-grid opacity-5"></div>
      <div className="absolute inset-0 bg-gradient-to-br from-funeral-light/30 via-transparent to-funeral-sandstone/20"></div>

      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-funeral-black via-funeral-dark to-funeral-black text-white py-12 md:py-16 overflow-hidden">
        {/* Holographic Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-funeral-accent/5 via-transparent to-funeral-medium/5"></div>
        
        {/* Tech Grid Lines */}
        <div className="absolute inset-0 tech-grid opacity-10"></div>
        
        {/* Floating Tech Elements */}
        <div className="absolute top-8 left-8 w-3 h-3 bg-funeral-accent/60 rounded-full animate-quantum-float"></div>
        <div className="absolute top-16 right-12 w-2 h-2 bg-funeral-sandstone/80 rounded-full animate-pulse-gentle" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-12 left-16 w-1.5 h-1.5 bg-funeral-medium/70 rounded-full animate-tech-glow" style={{animationDelay: '2s'}}></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center animate-fade-in">
            <div className="relative inline-block mb-4">
              <Palette className="mx-auto mb-3 h-10 w-10 md:h-12 md:w-12 text-funeral-sandstone animate-tech-glow" />
            </div>
            
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-heading font-bold mb-3 relative">
              <span className="relative z-10 text-white">AI Kist Ontwerp Studio (Coming soon)</span>
            </h1>
            
            <p className="text-base md:text-lg text-funeral-white/90 max-w-2xl mx-auto leading-relaxed">
              Ontwerp uw persoonlijke uitvaartkist met geavanceerde AI-technologie.
              <br className="hidden md:block" />
              <span className="text-funeral-sandstone font-medium">Van concept tot visualisatie in seconden.</span>
            </p>
          </div>
        </div>
        
        {/* Tech Corner Accents */}
        <div className="absolute top-4 left-4 w-6 h-6 border-l-2 border-t-2 border-funeral-accent/40 animate-tech-glow"></div>
        <div className="absolute top-4 right-4 w-6 h-6 border-r-2 border-t-2 border-funeral-accent/40 animate-tech-glow"></div>
        <div className="absolute bottom-4 left-4 w-6 h-6 border-l-2 border-b-2 border-funeral-accent/40 animate-tech-glow"></div>
        <div className="absolute bottom-4 right-4 w-6 h-6 border-r-2 border-b-2 border-funeral-accent/40 animate-tech-glow"></div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 md:py-12 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
          {/* Left Column - Input Controls */}
          <div className="space-y-6 animate-fade-in-up">
            <PromptInput 
              prompt={prompt}
              setPrompt={setPrompt}
              isLoading={isLoading}
            />
            
            <StylerControls 
              style={style}
              setStyle={setStyle}
            />
            
            <Button 
              onClick={handleGenerate}
              disabled={isLoading || !prompt.trim()}
              className="w-full bg-funeral-black hover:bg-funeral-dark text-white h-12 text-lg border-2 border-funeral-black hover:border-funeral-dark relative overflow-hidden hover-magnetic group"
            >
              {/* Button Background */}
              <div className="absolute inset-0 bg-gradient-to-r from-funeral-accent/10 to-funeral-sandstone/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              
              <span className="relative z-10 flex items-center justify-center">
                {isLoading ? (
                  <>
                    <Wand2 className="mr-2 h-5 w-5 animate-spin" />
                    <span>AI Genereert...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="mr-2 h-5 w-5 group-hover:animate-quantum-float" />
                    <span>Genereer Design</span>
                  </>
                )}
              </span>
            </Button>
          </div>

          {/* Right Column - Preview */}
          <div className="animate-fade-in-up" style={{animationDelay: '0.2s'}}>
            <KistPreview 
              generatedImage={generatedImage}
              isLoading={isLoading}
            />
          </div>
        </div>

        {/* Information Section */}
        <div className="mt-12 md:mt-16 relative animate-fade-in-up" style={{animationDelay: '0.4s'}}>
          {/* Background Container */}
          <div className="relative bg-white/95 rounded-2xl shadow-lg p-6 md:p-8 border border-funeral-accent/20">
            {/* Floating Energy Orbs */}
            <div className="absolute top-4 right-4 w-3 h-3 bg-funeral-accent/50 rounded-full animate-quantum-float"></div>
            <div className="absolute bottom-4 left-4 w-2 h-2 bg-funeral-medium/60 rounded-full animate-pulse-gentle" style={{animationDelay: '1s'}}></div>
            
            <h2 className="text-xl md:text-2xl font-heading font-semibold mb-6 text-funeral-dark text-center">
              Hoe werkt de AI Ontwerp Studio?
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
              <div className="text-center group relative">
                <div className="relative inline-block mb-4">
                  <div className="bg-gradient-to-br from-funeral-medium to-funeral-dark rounded-full w-12 h-12 flex items-center justify-center mx-auto animate-tech-glow group-hover:animate-liquid-morph">
                    <span className="text-white font-bold text-lg">1</span>
                  </div>
                  {/* Tech Corner Accents */}
                  <div className="absolute -top-1 -left-1 w-3 h-3 border-l-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <h3 className="font-heading font-semibold mb-2 text-funeral-dark text-base">Beschrijf uw visie</h3>
                <p className="text-funeral-text text-sm leading-relaxed">
                  Voer een gedetailleerde beschrijving in van uw gewenste kistontwerp met kleuren, thema's en symbolen.
                </p>
              </div>
              
              <div className="text-center group relative">
                <div className="relative inline-block mb-4">
                  <div className="bg-gradient-to-br from-funeral-medium to-funeral-dark rounded-full w-12 h-12 flex items-center justify-center mx-auto animate-tech-glow group-hover:animate-liquid-morph" style={{animationDelay: '0.5s'}}>
                    <span className="text-white font-bold text-lg">2</span>
                  </div>
                  <div className="absolute -top-1 -right-1 w-3 h-3 border-r-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <h3 className="font-heading font-semibold mb-2 text-funeral-dark text-base">AI Technologie</h3>
                <p className="text-funeral-text text-sm leading-relaxed">
                  Geavanceerde kunstmatige intelligentie creëert een uniek, photorealistisch design op basis van uw wensen.
                </p>
              </div>
              
              <div className="text-center group relative">
                <div className="relative inline-block mb-4">
                  <div className="bg-gradient-to-br from-funeral-medium to-funeral-dark rounded-full w-12 h-12 flex items-center justify-center mx-auto animate-tech-glow group-hover:animate-liquid-morph" style={{animationDelay: '1s'}}>
                    <span className="text-white font-bold text-lg">3</span>
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-3 h-3 border-r-2 border-b-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <h3 className="font-heading font-semibold mb-2 text-funeral-dark text-base">Realisatie & Contact</h3>
                <p className="text-funeral-text text-sm leading-relaxed">
                  Bekijk uw persoonlijke design en neem contact op voor professionele realisatie van uw unieke kist.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
    </>
  );
};

export default KistStyler;
