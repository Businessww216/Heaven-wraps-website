
import React from 'react';
import Sidebar from '@/components/Sidebar';
import HeaderContact from '@/components/HeaderContact';
import { RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import HeroPortfolio from '@/components/HeroPortfolio';
import PortfolioGrid from '@/components/PortfolioGrid';
import CallToActionSection from '@/components/CallToActionSection';
import TechBackgroundEffects from '@/components/TechBackgroundEffects';
import FadeInSection from '@/components/FadeInSection';
import { reloadAllImagesOnPage } from '@/utils/imageUtils';

const PortfolioGerapteKisten = () => {
  const handleRefreshImages = () => {
    reloadAllImagesOnPage();
  };

  return (
    <>
      <Sidebar />
      <HeaderContact />
      
      <div className="ml-0 md:ml-64 min-h-screen relative overflow-hidden tech-grid">
      <TechBackgroundEffects />
      
      {/* Hero Section with Tech Effects */}
      <HeroPortfolio />
      
      {/* Main Content */}
      <div className="page-container relative z-10">
        <div className="container mx-auto max-w-7xl px-6 md:px-8 lg:px-12">
          
          {/* Image Refresh Button */}
          <div className="flex justify-end mb-6">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center gap-2 text-funeral-medium hover:text-funeral-dark transition-colors"
              onClick={handleRefreshImages}
            >
              <RefreshCw size={16} />
              Afbeeldingen vernieuwen
            </Button>
          </div>
          
          {/* Portfolio Grid with Enhanced Tech Effects */}
          <PortfolioGrid />

          {/* Enhanced Call to Action with Cyberpunk Effects */}
          <FadeInSection delay={600}>
            <CallToActionSection />
          </FadeInSection>
        </div>
      </div>
      </div>
    </>
  );
};

export default PortfolioGerapteKisten;
