
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const CallToActionSection = () => {
  return (
    <div className="relative max-w-5xl mx-auto">
      {/* Holographic Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-funeral-light/80 via-funeral-offwhite/90 to-funeral-sandstone/80 backdrop-blur-sm rounded-2xl animate-hologram"></div>
      
      {/* Neon Border Glow */}
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-funeral-accent/20 via-transparent to-funeral-medium/20 animate-tech-glow"></div>
      
      <div className="text-center my-16 p-10 md:p-12 glassmorphism rounded-2xl border border-funeral-accent/30 relative">
        {/* Tech Grid Overlay */}
        <div className="absolute inset-0 tech-grid opacity-20 rounded-2xl"></div>
        
        <h2 className="text-3xl md:text-4xl font-heading mb-8 text-funeral-dark relative">
          <span className="cyberpunk-text">Advies nodig?</span>
          {/* Chrome Shine Effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform skew-x-12 opacity-0 hover:opacity-100 hover:animate-chrome-shine"></div>
        </h2>
        
        <p className="text-funeral-text text-xl md:text-2xl max-w-4xl mx-auto mb-10 leading-relaxed animate-neon-pulse relative z-10">
          Dit assortiment is slechts een deel van wat wij kunnen leveren. Maatwerk en persoonlijk advies zijn altijd mogelijk.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-6 justify-center relative z-10">
          <Button 
            asChild 
            className="bg-funeral-medium hover:bg-funeral-dark text-funeral-text hover:text-white hover:scale-105 active:scale-95 transition-all duration-300 px-8 py-4 text-lg group relative overflow-hidden animate-liquid-morph"
          >
            <Link to="/diensten">
              <span className="relative z-10">Bekijk onze producten</span>
              {/* Button Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-funeral-accent/20 to-funeral-dark/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </Link>
          </Button>
          
          <Button 
            asChild 
            variant="outline" 
            className="border-2 border-funeral-medium hover:bg-funeral-light text-funeral-dark hover:scale-105 active:scale-95 transition-all duration-300 px-8 py-4 text-lg hover-neon-glow relative"
          >
            <Link to="/contact">
              <span className="animate-neon-pulse">Vragen? Neem contact op</span>
            </Link>
          </Button>
        </div>
        
        {/* Floating Tech Elements */}
        <div className="absolute top-4 left-4 w-2 h-2 bg-funeral-accent/50 rounded-full animate-pulse-gentle"></div>
        <div className="absolute top-8 right-6 w-1 h-1 bg-funeral-medium/60 rounded-full animate-pulse-gentle" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-6 left-8 w-1.5 h-1.5 bg-funeral-dark/40 rounded-full animate-pulse-gentle" style={{animationDelay: '2s'}}></div>
      </div>
    </div>
  );
};

export default CallToActionSection;
