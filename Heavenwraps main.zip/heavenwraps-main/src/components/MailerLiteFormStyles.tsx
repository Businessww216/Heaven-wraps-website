
import React from 'react';

const MailerLiteFormStyles = () => {
  return (
    <style>{`
      @import url("https://assets.mlcdn.com/fonts.css?version=1750329");
      
      /* LOADER */
      .ml-form-embedSubmitLoad {
        display: inline-block;
        width: 20px;
        height: 20px;
      }

      .g-recaptcha {
        transform: scale(1);
        -webkit-transform: scale(1);
        transform-origin: 0 0;
        -webkit-transform-origin: 0 0;
        height: ;
      }

      .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0,0,0,0);
        border: 0;
      }

      .ml-form-embedSubmitLoad:after {
        content: " ";
        display: block;
        width: 11px;
        height: 11px;
        margin: 1px;
        border-radius: 50%;
        border: 4px solid #fff;
        border-color: #ffffff #ffffff #ffffff transparent;
        animation: ml-form-embedSubmitLoad 1.2s linear infinite;
      }
      
      @keyframes ml-form-embedSubmitLoad {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(360deg);
        }
      }
      
      #mlb2-27509637.ml-form-embedContainer {
        box-sizing: border-box;
        display: table;
        margin: 0 auto;
        position: static;
        width: 100% !important;
      }
      
      #mlb2-27509637.ml-form-embedContainer h4,
      #mlb2-27509637.ml-form-embedContainer p,
      #mlb2-27509637.ml-form-embedContainer span,
      #mlb2-27509637.ml-form-embedContainer button {
        text-transform: none !important;
        letter-spacing: normal !important;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper {
        background-color: #ffffff;
        border-width: 1px;
        border-color: #E6DED1;
        border-radius: 8px;
        border-style: solid;
        box-sizing: border-box;
        display: inline-block !important;
        margin: 0;
        padding: 0;
        position: relative;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper.embedPopup,
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper.embedDefault { 
        width: 100%; 
        max-width: 600px;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper.embedForm { 
        max-width: 100%; 
        width: 100%; 
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-align-center { 
        text-align: center; 
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody,
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-successBody {
        padding: 32px;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedContent h4 {
        color: #000000;
        font-family: 'Montserrat', Arial, Helvetica, sans-serif;
        font-size: 28px;
        font-weight: 600;
        margin: 0 0 16px 0;
        text-align: left;
        word-break: break-word;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedContent p {
        color: #333333;
        font-family: 'Poppins', Arial, Helvetica, sans-serif;
        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
        margin: 0 0 20px 0;
        text-align: left;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-block-form .ml-field-group {
        text-align: left!important;
        margin-bottom: 20px;
      }

      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-block-form .ml-field-group label {
        margin-bottom: 8px;
        color: #000000;
        font-size: 16px;
        font-family: 'Poppins', Arial, Helvetica, sans-serif;
        font-weight: 600;
        display: inline-block;
        line-height: 20px;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-fieldRow input {
        background-color: #ffffff !important;
        color: #333333 !important;
        border-color: #D4C4B0;
        border-radius: 6px !important;
        border-style: solid !important;
        border-width: 1px !important;
        font-family: 'Poppins', Arial, Helvetica, sans-serif;
        font-size: 16px !important;
        height: auto;
        line-height: 24px !important;
        margin-bottom: 0;
        margin-top: 0;
        margin-left: 0;
        margin-right: 0;
        padding: 12px 16px !important;
        width: 100% !important;
        box-sizing: border-box !important;
        max-width: 100% !important;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
      }

      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-fieldRow input:focus {
        border-color: #8B7355 !important;
        box-shadow: 0 0 0 3px rgba(139, 115, 85, 0.1) !important;
        outline: none !important;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-fieldRow textarea {
        background-color: #ffffff !important;
        color: #333333 !important;
        border-color: #D4C4B0;
        border-radius: 6px !important;
        border-style: solid !important;
        border-width: 1px !important;
        font-family: 'Poppins', Arial, Helvetica, sans-serif;
        font-size: 16px !important;
        height: auto;
        min-height: 120px;
        line-height: 24px !important;
        margin-bottom: 0;
        margin-top: 0;
        padding: 12px 16px !important;
        width: 100% !important;
        box-sizing: border-box !important;
        max-width: 100% !important;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
        resize: vertical;
      }

      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-fieldRow textarea:focus {
        border-color: #8B7355 !important;
        box-shadow: 0 0 0 3px rgba(139, 115, 85, 0.1) !important;
        outline: none !important;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedSubmit button {
        background-color: #8B7355 !important;
        border: none !important;
        border-radius: 6px !important;
        box-shadow: none !important;
        color: #ffffff !important;
        cursor: pointer;
        font-family: 'Poppins', Arial, Helvetica, sans-serif !important;
        font-size: 16px !important;
        font-weight: 600 !important;
        line-height: 24px !important;
        height: auto;
        padding: 14px 24px !important;
        width: 100% !important;
        box-sizing: border-box !important;
        transition: background-color 0.2s ease, transform 0.1s ease;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedSubmit button:hover {
        background-color: #000000 !important;
        transform: translateY(-1px);
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedSubmit button.loading {
        display: none;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-successBody .ml-form-successContent h4 {
        color: #000000;
        font-family: 'Montserrat', Arial, Helvetica, sans-serif;
        font-size: 24px;
        font-weight: 600;
        margin: 0 0 16px 0;
        text-align: center;
      }
      
      #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-successBody .ml-form-successContent p {
        color: #333333;
        font-family: 'Poppins', Arial, Helvetica, sans-serif;
        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
        margin: 0;
        text-align: center;
      }

      .ml-error input, .ml-error textarea, .ml-error select {
        border-color: #ef4444!important;
      }

      @media only screen and (max-width: 640px) {
        #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody {
          padding: 24px;
        }
        
        #mlb2-27509637.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedContent h4 {
          font-size: 24px;
        }
      }
    `}</style>
  );
};

export default MailerLiteFormStyles;
