
import React from 'react';
import { cn } from '@/lib/utils';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
}

const Button = ({ 
  children, 
  className, 
  variant = 'primary', 
  size = 'md', 
  ...props 
}: ButtonProps) => {
  
  const baseStyles = "inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50";
  
  const variants = {
    primary: "bg-funeral-medium hover:bg-funeral-dark text-funeral-text hover:text-white",
    secondary: "bg-funeral-accent hover:bg-funeral-accent/80 text-funeral-dark",
    outline: "border border-funeral-medium hover:bg-funeral-light text-funeral-dark",
    ghost: "hover:bg-funeral-light hover:text-funeral-dark text-funeral-text"
  };
  
  const sizes = {
    sm: "h-8 px-4 py-1",
    md: "h-10 px-6 py-2",
    lg: "h-12 px-8 py-3 text-base"
  };
  
  return (
    <button
      className={cn(
        baseStyles,
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;
