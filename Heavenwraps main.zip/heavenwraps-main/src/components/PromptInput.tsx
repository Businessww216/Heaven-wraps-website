
import React from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Lightbulb } from 'lucide-react';

interface PromptInputProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  isLoading: boolean;
}

const PromptInput: React.FC<PromptInputProps> = ({
  prompt,
  setPrompt,
  isLoading
}) => {
  return (
    <div className="relative group">
      {/* Main Container */}
      <div className="relative bg-white/95 rounded-xl shadow-lg p-6 border border-funeral-accent/20 hover-tech-lift transition-all duration-500">
        {/* Tech Corner Accents */}
        <div className="absolute top-3 left-3 w-4 h-4 border-l-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-tech-glow"></div>
        <div className="absolute top-3 right-3 w-4 h-4 border-r-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-tech-glow"></div>
        
        {/* Floating Energy Orb */}
        <div className="absolute top-4 right-4 w-2 h-2 bg-funeral-accent/50 rounded-full opacity-0 group-hover:opacity-100 animate-quantum-float"></div>
        
        <Label htmlFor="prompt" className="text-lg font-heading font-semibold text-funeral-dark mb-4 block relative">
          <span>Beschrijf uw gewenste kist design</span>
          {/* Neon Underline */}
          <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-funeral-accent to-funeral-medium group-hover:w-full transition-all duration-500"></div>
        </Label>
        
        <div className="relative">
          <Textarea 
            id="prompt" 
            value={prompt} 
            onChange={e => setPrompt(e.target.value)} 
            placeholder="Beschrijf in detail hoe u uw kist wilt laten ontwerpen. Denk aan kleuren, thema's, symbolen, natuur elementen, of persoonlijke herinneringen..." 
            className="min-h-[120px] text-base border-2 border-funeral-medium/30 focus:border-funeral-accent/80 resize-none bg-white rounded-lg transition-all duration-300 focus:shadow-lg" 
            disabled={isLoading} 
            maxLength={1000} 
          />
          
          {/* Focus Glow Effect */}
          <div className="absolute inset-0 rounded-lg border-2 border-funeral-accent/0 group-focus-within:border-funeral-accent/30 transition-all duration-300 pointer-events-none"></div>
        </div>
        
        {/* Character Counter */}
        <div className="mt-4 relative">
          <div className="flex justify-between items-center">
            <div className="text-sm text-funeral-text relative">
              <span>{prompt.length}/1000 karakters</span>
            </div>
            
            {/* AI Hint */}
            {prompt.length < 50 && (
              <div className="flex items-center text-xs text-funeral-medium animate-pulse-gentle">
                <Lightbulb className="w-3 h-3 mr-1" />
                <span>Meer detail = beter resultaat</span>
              </div>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-2 h-1 bg-funeral-offwhite/50 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-funeral-accent to-funeral-medium transition-all duration-300"
            style={{ width: `${(prompt.length / 1000) * 100}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default PromptInput;
