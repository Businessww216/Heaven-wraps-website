
import React from "react";
import ServiceCard from "./ServiceCard";

interface AnimatedServiceCardProps extends React.ComponentProps<typeof ServiceCard> {
  delay?: number;
}

const AnimatedServiceCard: React.FC<AnimatedServiceCardProps> = ({ delay = 0, ...props }) => (
  <div
    className={`transition-transform duration-700 relative group perspective-1000 ${
      props.isComingSoon 
        ? 'cursor-default animate-digital-glitch' 
        : 'hover:scale-105 hover:shadow-2xl hover:ring-2 hover:ring-funeral-medium/40 hover-tech-lift'
    }`}
    style={{ transitionDelay: `${delay}ms` }}
  >
    {/* Enhanced Tech Background Effects */}
    <div className="absolute inset-0 bg-gradient-to-br from-funeral-accent/5 via-transparent to-funeral-medium/5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-hologram"></div>
    
    {/* Quantum Field Effect */}
    <div className="absolute -inset-2 bg-gradient-to-r from-funeral-accent/10 via-funeral-medium/10 to-funeral-dark/10 rounded-lg opacity-0 group-hover:opacity-100 group-hover:animate-quantum-float transition-all duration-700"></div>
    
    {/* Chrome Reflection Overlay */}
    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-chrome-reflection rounded-lg"></div>
    
    <ServiceCard {...props} />
    
    {/* Enhanced Glow Effect - alleen voor beschikbare items */}
    {!props.isComingSoon && (
      <>
        <div className="absolute inset-0 rounded-lg pointer-events-none opacity-0 group-hover:opacity-60 transition-opacity duration-500 group-hover:shadow-[0_0_40px_12px_rgba(230,222,209,0.4)]"></div>
        
        {/* Neon Pulse Border */}
        <div className="absolute inset-0 rounded-lg border border-funeral-accent/0 group-hover:border-funeral-accent/50 group-hover:animate-neon-pulse transition-all duration-500"></div>
        
        {/* Floating Energy Orbs */}
        <div className="absolute top-2 right-2 w-1 h-1 bg-funeral-accent/70 rounded-full opacity-0 group-hover:opacity-100 animate-pulse-gentle group-hover:animate-quantum-float"></div>
        <div className="absolute bottom-2 left-2 w-0.5 h-0.5 bg-funeral-medium/60 rounded-full opacity-0 group-hover:opacity-100 animate-pulse-gentle group-hover:animate-quantum-float" style={{animationDelay: '0.5s'}}></div>
      </>
    )}
    
    {/* Coming Soon Digital Effects */}
    {props.isComingSoon && (
      <>
        <div className="absolute inset-0 bg-gradient-to-br from-funeral-dark/10 via-transparent to-funeral-dark/10 rounded-lg animate-digital-glitch"></div>
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-funeral-dark/50 to-transparent animate-cyber-scan"></div>
      </>
    )}
  </div>
);

export default AnimatedServiceCard;
