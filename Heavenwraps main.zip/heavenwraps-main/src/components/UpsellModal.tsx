
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, Sparkles } from 'lucide-react';

interface UpsellModalProps {
  isOpen: boolean;
  onClose: () => void;
  originalProduct?: {
    title: string;
    price: string;
    image: string;
  } | null;
  upsellProduct?: {
    title: string;
    price: string;
    image: string;
    description: string;
  } | null;
}

const UpsellModal: React.FC<UpsellModalProps> = ({
  isOpen,
  onClose,
  originalProduct,
  upsellProduct
}) => {
  // Early return if no products are provided
  if (!originalProduct || !upsellProduct) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-full mx-auto p-0 bg-white rounded-lg shadow-2xl">
        <DialogHeader className="p-6 pb-4">
          <DialogTitle className="text-2xl font-heading font-semibold text-funeral-dark flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-funeral-accent" />
            Upgrade uw keuze
          </DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute top-4 right-4 h-8 w-8 p-0 hover:bg-funeral-light/50"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        <div className="px-6 pb-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Original Product */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-funeral-medium">Uw huidige keuze</h3>
              <div className="bg-funeral-offwhite/50 rounded-lg p-4">
                <img 
                  src={originalProduct.image} 
                  alt={originalProduct.title}
                  className="w-full h-48 object-cover rounded-lg mb-3"
                />
                <h4 className="font-medium text-funeral-dark">{originalProduct.title}</h4>
                <p className="text-funeral-accent font-semibold">{originalProduct.price}</p>
              </div>
            </div>

            {/* Upsell Product */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-funeral-medium">Aanbevolen upgrade</h3>
              <div className="bg-gradient-to-br from-funeral-light/30 to-funeral-accent/10 rounded-lg p-4 border-2 border-funeral-accent/20">
                <img 
                  src={upsellProduct.image} 
                  alt={upsellProduct.title}
                  className="w-full h-48 object-cover rounded-lg mb-3"
                />
                <h4 className="font-medium text-funeral-dark">{upsellProduct.title}</h4>
                <p className="text-sm text-funeral-text mb-2">{upsellProduct.description}</p>
                <p className="text-funeral-accent font-semibold text-lg">{upsellProduct.price}</p>
              </div>
            </div>
          </div>

          <div className="flex gap-4 mt-6 justify-end">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="border-funeral-medium text-funeral-medium hover:bg-funeral-light/50"
            >
              Blijf bij originele keuze
            </Button>
            <Button 
              onClick={onClose}
              className="bg-funeral-accent hover:bg-funeral-accent/90 text-white"
            >
              Upgrade naar {upsellProduct.title}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default UpsellModal;
