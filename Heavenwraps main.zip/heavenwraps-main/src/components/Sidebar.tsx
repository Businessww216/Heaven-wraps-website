
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Home, Info, Image, Euro, Contact, FileText, Menu, Phone, Mail, MessageSquare, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isQuoteDialogOpen, setIsQuoteDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const location = useLocation();
  const { toast } = useToast();
  
  const navigation = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Over ons', href: '/over-ons', icon: Info },
    { name: 'Portfolio gewrapte kisten', href: '/portfolio-gerapte-kisten', icon: Image },
    { name: 'Assortiment kale kisten', href: '/assortiment-kale-kisten', icon: Image },
    { name: 'Custom made', href: '/kist-styler', icon: Palette },
    { name: 'Contact', href: '/contact', icon: Contact },
  ];

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const handleBrochureDownload = () => {
    const link = document.createElement('a');
    link.href = 'https://drive.google.com/uc?export=download&id=1YsD8Kl2CZBh_3bJigmUGv5mRQSnaMA3M';
    link.download = 'Heaven-Wraps-Brochure.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleQuoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Fout",
        description: "Vul alle velden in alstublieft.",
        variant: "destructive",
      });
      return;
    }

    // Hier zou normaal gesproken de form data naar een server worden gestuurd
    console.log('Quote form submitted:', formData);
    
    toast({
      title: "Offerte aanvraag verzonden!",
      description: "We nemen zo snel mogelijk contact met u op.",
    });

    // Reset form
    setFormData({ name: '', email: '', message: '' });
    setIsQuoteDialogOpen(false);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <>
      <button 
        className="fixed top-4 left-4 z-50 md:hidden bg-funeral-white rounded-full p-2 shadow-md hover:scale-110 transition-transform duration-200"
        onClick={toggleSidebar}
      >
        <Menu size={24} className="text-funeral-black" />
      </button>
      
      <aside className={cn(
        "fixed inset-y-0 left-0 z-40 transform transition-all duration-300 ease-in-out bg-funeral-black shadow-lg flex flex-col min-h-screen",
        isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
        "md:w-64 w-64"
      )}>
        <div className="px-6 py-8 animate-fade-in">
          <Link to="/" className="flex items-center justify-center group">
            <h1 className="text-3xl font-bold text-funeral-sandstone group-hover:scale-105 transition-transform duration-200">HEAVEN WRAPS</h1>
          </Link>
        </div>
        
        <div className="flex-1 px-4 overflow-y-auto">
          <nav className="space-y-1 py-4">
            {navigation.map((item, index) => {
              const isActive = location.pathname === item.href;
              
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={cn(
                    "flex items-center px-4 py-3 text-sm rounded-md transition-all duration-200 hover:translate-x-1 animate-fade-in",
                    isActive
                      ? "bg-funeral-sandstone text-funeral-black font-medium shadow-lg"
                      : "text-funeral-white hover:bg-funeral-white/10 hover:shadow-md"
                  )}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <item.icon className="mr-3 h-5 w-5 transition-transform duration-200 group-hover:scale-110" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Quote Button */}
        <div className="p-4 border-t border-funeral-white/10">
          <Dialog open={isQuoteDialogOpen} onOpenChange={setIsQuoteDialogOpen}>
            <DialogTrigger asChild>
              <Button
                className="w-full bg-funeral-sandstone hover:bg-funeral-sandstone/80 text-funeral-black mb-3 hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <MessageSquare className="mr-2 h-4 w-4" />
                Offerte Aanvragen
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px] bg-funeral-offwhite">
              <DialogHeader>
                <DialogTitle className="text-funeral-black">Offerte Aanvragen</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleQuoteSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-funeral-black">Naam</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder="Uw volledige naam"
                    className="border-funeral-text/20 focus:border-funeral-black"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-funeral-black">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="uw.email@example.com"
                    className="border-funeral-text/20 focus:border-funeral-black"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message" className="text-funeral-black">Bericht</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => handleInputChange('message', e.target.value)}
                    placeholder="Beschrijf uw wensen voor de uitvaartkist..."
                    rows={4}
                    className="border-funeral-text/20 focus:border-funeral-black"
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-funeral-black hover:bg-funeral-black/80 text-funeral-white"
                >
                  Verzend Aanvraag
                </Button>
              </form>
            </DialogContent>
          </Dialog>
          
          <Button
            className="w-full bg-funeral-sandstone hover:bg-funeral-sandstone/80 text-funeral-black hover:scale-105 transition-all duration-200"
            onClick={handleBrochureDownload}
          >
            Download Brochure
          </Button>
        </div>
      </aside>
      
      {/* Overlay to close sidebar on mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden transition-opacity duration-300"
          onClick={toggleSidebar}
        />
      )}
    </>
  );
};

export default Sidebar;
