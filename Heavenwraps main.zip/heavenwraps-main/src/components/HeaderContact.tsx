
import React from 'react';
import { Phone, Mail } from 'lucide-react';

const HeaderContact = () => {
  return (
    <div className="fixed top-4 right-4 z-50 flex items-center space-x-4 bg-funeral-white/90 backdrop-blur-sm rounded-lg px-4 py-2 shadow-md">
      <a 
        href="tel:0613396483" 
        className="flex items-center text-funeral-black hover:text-funeral-medium transition-colors duration-200 group"
      >
        <Phone className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform" />
        <span className="text-sm font-medium">0613396483</span>
      </a>
      <div className="w-px h-4 bg-funeral-text/20"></div>
      <a 
        href="mailto:info@heaven-wraps.nl" 
        className="flex items-center text-funeral-black hover:text-funeral-medium transition-colors duration-200 group"
      >
        <Mail className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform" />
        <span className="text-sm font-medium">info@heaven-wraps.nl</span>
      </a>
    </div>
  );
};

export default HeaderContact;
