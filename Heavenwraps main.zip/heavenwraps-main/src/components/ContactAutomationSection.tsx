
import React from 'react';
import WebhookIntegration from '@/components/WebhookIntegration';
import FadeInSection from '@/components/FadeInSection';
import { Zap } from 'lucide-react';

const ContactAutomationSection = () => {
  return (
    <FadeInSection delay={800}>
      <div className="my-16 relative">
        {/* Tech Background */}
        <div className="absolute inset-0 bg-gradient-to-r from-funeral-black/5 via-transparent to-funeral-medium/5 rounded-3xl"></div>
        
        <div className="relative bg-white/90 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-funeral-accent/30 hover:border-funeral-accent/50 transition-all duration-500">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-funeral-accent to-funeral-medium flex items-center justify-center animate-liquid-morph shadow-xl">
                <Zap className="text-funeral-dark" size={32}/>
              </div>
            </div>
            
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4 text-funeral-dark">
              Automatisering & Integraties
            </h2>
            <p className="text-lg text-funeral-text max-w-2xl mx-auto leading-relaxed">
              Ervaar onze geavanceerde technologie voor naadloze communicatie en procesoptimalisatie.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <WebhookIntegration />
          </div>
        </div>
      </div>
    </FadeInSection>
  );
};

export default ContactAutomationSection;
