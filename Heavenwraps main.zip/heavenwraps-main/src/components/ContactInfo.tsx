
import React from 'react';
import { Button } from '@/components/ui/button';
import { Mail, Phone, MapPin, Clock, Download } from 'lucide-react';

const ContactInfo = () => {
  const handleBrochureDownload = () => {
    const link = document.createElement('a');
    link.href = 'https://drive.google.com/uc?export=download&id=1YsD8Kl2CZBh_3bJigmUGv5mRQSnaMA3M';
    link.download = 'Heaven-Wraps-Brochure.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="relative group">
      <div className="absolute -inset-1 bg-gradient-to-r from-funeral-medium/30 to-funeral-accent/30 rounded-xl blur-lg group-hover:blur-xl transition-all duration-500"></div>
      
      <div className="relative bg-white/95 backdrop-blur-sm p-8 rounded-xl shadow-lg border border-funeral-medium/20 hover:border-funeral-medium/40 transition-all duration-500 hover-tech-lift">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-funeral-accent to-funeral-medium flex items-center justify-center animate-quantum-float shadow-lg">
            <Mail className="text-funeral-dark" size={24}/>
          </div>
          <h3 className="text-2xl font-heading font-semibold text-funeral-dark">Onze gegevens</h3>
        </div>

        <div className="space-y-8">
          <div className="flex items-start gap-4 group/item hover:bg-funeral-accent/5 p-4 rounded-lg transition-all duration-300">
            <div className="w-10 h-10 rounded-full bg-funeral-medium/20 flex items-center justify-center mt-1 group-hover/item:animate-quantum-float">
              <MapPin className="text-funeral-medium" size={20}/>
            </div>
            <div>
              <h4 className="text-lg font-heading font-medium mb-3 text-funeral-dark">Adres</h4>
              <address className="not-italic text-funeral-text leading-relaxed">
                <p className="font-medium">Heaven Wraps</p>
                <p>Hoofdstraat 123</p>
                <p>1234 AB Amsterdam</p>
              </address>
            </div>
          </div>
          
          <div className="flex items-start gap-4 group/item hover:bg-funeral-accent/5 p-4 rounded-lg transition-all duration-300">
            <div className="w-10 h-10 rounded-full bg-funeral-medium/20 flex items-center justify-center mt-1 group-hover/item:animate-quantum-float">
              <Phone className="text-funeral-medium" size={20}/>
            </div>
            <div>
              <h4 className="text-lg font-heading font-medium mb-3 text-funeral-dark">Contactgegevens</h4>
              <p className="text-funeral-text mb-2">
                Telefoon: <a href="tel:0201234567" className="hover:text-funeral-accent transition-colors underline underline-offset-2 font-medium">020-123 45 67</a>
              </p>
              <p className="text-funeral-text">
                E-mail: <a href="mailto:info@heavenwraps.nl" className="hover:text-funeral-accent transition-colors underline underline-offset-2 font-medium">info@heavenwraps.nl</a>
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-4 group/item hover:bg-funeral-accent/5 p-4 rounded-lg transition-all duration-300">
            <div className="w-10 h-10 rounded-full bg-funeral-medium/20 flex items-center justify-center mt-1 group-hover/item:animate-quantum-float">
              <Clock className="text-funeral-medium" size={20}/>
            </div>
            <div>
              <h4 className="text-lg font-heading font-medium mb-3 text-funeral-dark">Openingstijden</h4>
              <div className="text-funeral-text space-y-1">
                <p>Maandag t/m vrijdag: <span className="font-medium">09:00 - 17:00</span></p>
                <p>Zaterdag: <span className="font-medium">Op afspraak</span></p>
                <p>Zondag: <span className="font-medium">Op afspraak</span></p>
                <p className="mt-3 text-funeral-black font-semibold bg-funeral-accent/10 p-2 rounded-md">
                  Voor spoedgevallen zijn wij 24/7 bereikbaar
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-funeral-medium/20">
          <Button 
            className="bg-funeral-accent hover:bg-funeral-accent/80 text-funeral-dark w-full hover:scale-105 transition-all duration-300 h-12 text-lg font-medium relative overflow-hidden group"
            onClick={handleBrochureDownload}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
            <Download className="mr-2 h-5 w-5 group-hover:animate-quantum-float" />
            <span className="relative z-10">Download onze brochure</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ContactInfo;
