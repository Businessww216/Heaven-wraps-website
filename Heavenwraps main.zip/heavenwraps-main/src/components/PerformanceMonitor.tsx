
import { useEffect, useState } from 'react';

const PerformanceMonitor = () => {
  const [performanceData, setPerformanceData] = useState<{
    loadTime: number;
    imagesLoaded: number;
    totalImages: number;
  }>({
    loadTime: 0,
    imagesLoaded: 0,
    totalImages: 0
  });

  useEffect(() => {
    // Register service worker
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
          .then((registration) => {
            console.log('SW registered: ', registration);
          })
          .catch((registrationError) => {
            console.log('SW registration failed: ', registrationError);
          });
      });
    }

    // Monitor page load performance
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'navigation') {
          const navigationEntry = entry as PerformanceNavigationTiming;
          setPerformanceData(prev => ({
            ...prev,
            loadTime: navigationEntry.loadEventEnd - navigationEntry.loadEventStart
          }));
        }
      }
    });

    observer.observe({ entryTypes: ['navigation'] });

    // Monitor image loading
    const images = document.querySelectorAll('img');
    let loadedCount = 0;
    
    const checkImageLoad = () => {
      loadedCount++;
      setPerformanceData(prev => ({
        ...prev,
        imagesLoaded: loadedCount,
        totalImages: images.length
      }));
    };

    images.forEach(img => {
      if (img.complete) {
        checkImageLoad();
      } else {
        img.addEventListener('load', checkImageLoad);
        img.addEventListener('error', checkImageLoad);
      }
    });

    return () => {
      observer.disconnect();
      images.forEach(img => {
        img.removeEventListener('load', checkImageLoad);
        img.removeEventListener('error', checkImageLoad);
      });
    };
  }, []);

  // Only show in development
  if (process.env.NODE_ENV === 'production') {
    return null;
  }

  return (
    <div className="fixed bottom-4 left-4 bg-black/80 text-white p-2 rounded text-xs z-50">
      <div>Load: {performanceData.loadTime.toFixed(0)}ms</div>
      <div>Images: {performanceData.imagesLoaded}/{performanceData.totalImages}</div>
    </div>
  );
};

export default PerformanceMonitor;
