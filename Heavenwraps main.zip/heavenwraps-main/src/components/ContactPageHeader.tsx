
import React from 'react';
import FadeInSection from '@/components/FadeInSection';

const ContactPageHeader = () => {
  return (
    <>
      <FadeInSection delay={0}>
        <div className="relative text-center mb-8">
          {/* Tech Corner Accents */}
          <div className="absolute -top-4 -left-4 w-8 h-8 border-l-2 border-t-2 border-funeral-accent/40 animate-tech-glow"></div>
          <div className="absolute -top-4 -right-4 w-8 h-8 border-r-2 border-t-2 border-funeral-accent/40 animate-tech-glow"></div>
          
          <h1 className="page-title text-4xl md:text-5xl lg:text-6xl font-heading font-bold mb-6 relative">
            <span className="relative z-10">Contact</span>
          </h1>
          
          <div className="absolute bottom-4 left-4 w-6 h-6 border-l-2 border-b-2 border-funeral-accent/40 animate-tech-glow"></div>
          <div className="absolute bottom-4 right-4 w-6 h-6 border-r-2 border-b-2 border-funeral-accent/40 animate-tech-glow"></div>
        </div>
      </FadeInSection>

      <FadeInSection delay={100}>
        <div className="text-center mb-12 relative">
          <p className="text-xl md:text-2xl text-funeral-text mb-4 max-w-4xl mx-auto leading-relaxed animate-fade-in-up">
            Heeft u vragen, of wilt u een persoonlijk gesprek om de mogelijkheden te bespreken? 
            <span className="text-funeral-black font-medium block mt-2">Wij staan voor u klaar.</span>
          </p>
          
          {/* Floating Tech Accent */}
          <div className="absolute top-0 right-8 w-12 h-12 bg-gradient-to-br from-funeral-accent/20 to-funeral-medium/20 rounded-full animate-liquid-morph"></div>
        </div>
      </FadeInSection>
    </>
  );
};

export default ContactPageHeader;
