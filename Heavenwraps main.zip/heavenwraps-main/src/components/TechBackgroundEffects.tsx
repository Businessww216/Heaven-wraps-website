
import React from 'react';
import TechParticles from '@/components/TechParticles';

const TechBackgroundEffects: React.FC = () => {
  return (
    <>
      {/* Futuristic Background Effects */}
      <TechParticles />
      
      {/* Quantum Floating Nodes */}
      <div className="fixed top-10 left-10 w-2 h-2 bg-funeral-medium/40 rounded-full animate-quantum-float z-0"></div>
      <div className="fixed top-1/3 right-20 w-1 h-1 bg-funeral-accent/60 rounded-full animate-quantum-float z-0" style={{animationDelay: '2s'}}></div>
      <div className="fixed bottom-1/4 left-1/4 w-1.5 h-1.5 bg-funeral-dark/30 rounded-full animate-quantum-float z-0" style={{animationDelay: '4s'}}></div>
      
      {/* Matrix Connection Lines */}
      <svg className="fixed inset-0 w-full h-full pointer-events-none opacity-10 z-0">
        <defs>
          <pattern id="matrix-lines" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
            <path d="M0,50 Q50,0 100,50" stroke="url(#matrix-gradient)" strokeWidth="0.5" fill="none"/>
          </pattern>
          <linearGradient id="matrix-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="transparent"/>
            <stop offset="50%" stopColor="#E6DED1"/>
            <stop offset="100%" stopColor="transparent"/>
          </linearGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#matrix-lines)"/>
      </svg>
    </>
  );
};

export default TechBackgroundEffects;
