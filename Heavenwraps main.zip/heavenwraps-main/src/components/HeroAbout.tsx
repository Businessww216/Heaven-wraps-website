
import React from "react";
import { cn } from "@/lib/utils";
import TechParticles from "./TechParticles";

const HeroAbout = () => (
  <section className="relative bg-gradient-to-br from-funeral-sandstone via-funeral-offwhite to-funeral-white py-16 md:py-28 mb-8 overflow-hidden">
    {/* Enhanced Tech Particles Background */}
    <TechParticles />
    
    {/* Dynamic Gradient Morphing Background */}
    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-funeral-sandstone/10 to-transparent opacity-50 animate-liquid-morph"></div>
    
    {/* Floating Geometric Shapes */}
    <div className="absolute top-10 left-10 w-20 h-20 border border-funeral-medium/30 rounded-lg animate-quantum-float opacity-40"></div>
    <div className="absolute bottom-20 right-20 w-16 h-16 bg-funeral-dark/10 rounded-full animate-quantum-float [animation-delay:2s] opacity-30"></div>
    <div className="absolute top-1/2 left-1/4 w-12 h-12 border-2 border-funeral-accent/20 rotate-45 animate-quantum-float [animation-delay:4s]"></div>
    
    <div className="container mx-auto px-4 flex flex-col gap-6 items-center justify-center text-center relative z-10">
      {/* Holographic Title with Shimmer Effect */}
      <h1 className={cn(
        "text-4xl md:text-5xl lg:text-6xl font-heading font-semibold mb-3 text-funeral-dark relative",
        "bg-gradient-to-r from-funeral-black via-funeral-text to-funeral-dark bg-clip-text text-transparent",
        "animate-fade-in"
      )}>
        <span className="relative inline-block">
          Over Heaven Wraps
          {/* Holographic shimmer overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12 animate-chrome-shine"></div>
        </span>
      </h1>
      
      {/* Typewriter Effect Subtitle */}
      <div className="text-xl md:text-2xl max-w-2xl text-funeral-text mb-4 animate-fade-in-slow [animation-delay:150ms]">
        <div className="overflow-hidden">
          <span className="block animate-fade-in [animation-delay:300ms] hover:animate-neon-pulse cursor-default">
            Liefdevol, persoonlijk en onderscheidend afscheid. 
          </span>
          <span className="block mt-2 animate-fade-in [animation-delay:600ms] hover:animate-neon-pulse cursor-default">
            Ontdek hoe ons team samen met jou een bijzondere herinnering creëert.
          </span>
        </div>
      </div>
      
      {/* Interactive glow effect on hover */}
      <div className="absolute inset-0 opacity-0 hover:opacity-20 transition-opacity duration-500 bg-gradient-radial from-funeral-accent/20 to-transparent pointer-events-none"></div>
    </div>
    
    {/* Enhanced Background Shapes with Animation */}
    <svg className="absolute left-0 bottom-0 w-48 md:w-72 opacity-10 animate-quantum-float" viewBox="0 0 200 200" fill="none">
      <ellipse cx="100" cy="100" rx="100" ry="70" fill="#E6DED1" />
    </svg>
    <svg className="absolute right-0 top-0 w-24 md:w-40 opacity-10 animate-quantum-float [animation-delay:3s]" viewBox="0 0 100 100" fill="none">
      <circle cx="50" cy="50" r="50" fill="#000" />
    </svg>
    
    {/* Floating connection lines */}
    <div className="absolute top-1/4 left-1/2 w-px h-20 bg-gradient-to-b from-funeral-accent/0 via-funeral-accent/30 to-funeral-accent/0 animate-fade-in [animation-delay:1s]"></div>
    <div className="absolute bottom-1/4 right-1/3 w-20 h-px bg-gradient-to-r from-funeral-accent/0 via-funeral-accent/30 to-funeral-accent/0 animate-fade-in [animation-delay:1.5s]"></div>
  </section>
);

export default HeroAbout;
