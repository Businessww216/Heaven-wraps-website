
import React, { useState } from "react";
import { CircleCheck, Heart, Star, Leaf } from "lucide-react";

interface ValueCardProps {
  title: string;
  description: string;
  icon: "respect" | "aandacht" | "kwaliteit" | "duurzaamheid";
  className?: string;
}

const icons = {
  respect: <CircleCheck className="text-funeral-accent" size={32} />,
  aandacht: <Heart className="text-funeral-accent" size={32} />,
  kwaliteit: <Star className="text-funeral-accent" size={32} />,
  duurzaamheid: <Leaf className="text-funeral-accent" size={32} />,
};

const ValueCard = ({ title, description, icon, className }: ValueCardProps) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div className={`group perspective-1000 h-full ${className ?? ""}`}>
      <div 
        className="relative w-full h-full transition-all duration-700 preserve-3d hover:rotate-y-12 animate-fade-in [animation-delay:100ms]"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Main Card with 3D Effects */}
        <div className="relative bg-white/90 rounded-lg shadow-lg p-6 border border-funeral-sandstone/30 hover:shadow-2xl transition-all duration-700 overflow-hidden hover-tech-lift h-full min-h-[320px] flex flex-col">
          
          {/* Neon Glow Border Effect */}
          <div className={`absolute inset-0 rounded-lg transition-all duration-500 ${isHovered ? 'animate-tech-glow' : ''}`}>
            <div className="absolute inset-0 bg-gradient-to-r from-funeral-accent/20 via-transparent to-funeral-accent/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          </div>
          
          {/* Holographic Overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-funeral-sandstone/0 via-funeral-medium/5 to-funeral-dark/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 hover-hologram rounded-lg"></div>
          
          {/* Magnetic Hover Effect Content */}
          <div className="relative z-10 flex flex-col h-full animate-magnetic-hover text-center">
            {/* Levitating Icon Container - Centered at top */}
            <div className="flex justify-center mb-4">
              <div className="flex-shrink-0 p-2 rounded-lg bg-funeral-offwhite/50 group-hover:bg-funeral-light/70 transition-all duration-500 hover:animate-quantum-float">
                <div className="transform group-hover:scale-110 transition-transform duration-500 animate-fade-in [animation-delay:200ms]">
                  {icons[icon]}
                </div>
              </div>
            </div>
            
            {/* Futuristic Title with Chrome Effect - Centered */}
            <div className="mb-4">
              <h3 className="text-lg font-serif font-medium text-funeral-dark group-hover:text-funeral-black transition-colors duration-500 relative leading-tight">
                <span className="relative inline-block">
                  {title}
                  {/* Chrome reflection effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-6 opacity-0 group-hover:opacity-100 group-hover:animate-chrome-reflection"></div>
                </span>
              </h3>
            </div>
            
            {/* Description Section - Flex grow to fill remaining space */}
            <div className="flex-1 flex flex-col justify-start">
              <p className="text-funeral-text group-hover:text-funeral-dark transition-colors duration-500 leading-relaxed text-sm">
                {description}
              </p>
            </div>
          </div>
          
          {/* Particle Trail Effect */}
          <div className="absolute bottom-2 right-2 w-2 h-2 bg-funeral-accent/30 rounded-full opacity-0 group-hover:opacity-100 animate-fade-in [animation-delay:500ms]"></div>
          <div className="absolute bottom-3 right-4 w-1 h-1 bg-funeral-accent/20 rounded-full opacity-0 group-hover:opacity-100 animate-fade-in [animation-delay:700ms]"></div>
          
          {/* Cyber scan line */}
          <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-funeral-accent/50 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-cyber-scan"></div>
        </div>
        
        {/* Floating connection nodes */}
        <div className="absolute -top-2 -left-2 w-1 h-1 bg-funeral-accent/40 rounded-full opacity-0 group-hover:opacity-100 animate-pulse-gentle [animation-delay:300ms]"></div>
        <div className="absolute -bottom-2 -right-2 w-1 h-1 bg-funeral-accent/40 rounded-full opacity-0 group-hover:opacity-100 animate-pulse-gentle [animation-delay:600ms]"></div>
      </div>
    </div>
  );
};

export default ValueCard;
