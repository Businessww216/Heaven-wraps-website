
import React from "react";
import { Sparkle, GalleryHorizontal } from "lucide-react";

const HeroPortfolio = () => (
  <section className="relative bg-gradient-to-br from-funeral-sandstone via-funeral-offwhite to-funeral-white py-16 md:py-24 mb-8 overflow-hidden animate-fade-in-slow">
    <div className="container mx-auto px-4 flex flex-col gap-7 items-center justify-center text-center relative z-10">
      <span className="inline-flex items-center gap-2 text-funeral-dark text-xl font-heading font-bold opacity-90 animate-fade-in [animation-delay:200ms]">
        <GalleryHorizontal size={30} className="text-funeral-medium animate-wiggle-slow2" />
        Portfolio & Inspiratie
      </span>
      <h1 className="text-3xl sm:text-4xl md:text-5xl font-heading font-semibold mb-2 text-funeral-dark drop-shadow animate-fade-in [animation-delay:300ms]">
        Laat u inspireren door onze persoonlijke ontwerpen
      </h1>
      <p className="text-xl md:text-2xl text-funeral-text mb-2 max-w-2xl mx-auto animate-fade-in [animation-delay:400ms]">
        Elk ontwerp vertelt een bijzonder verhaal. Scroll en ontdek unieke kisten – vol kleur, persoonlijkheid en liefde.
      </p>
      <Sparkle className="absolute top-8 left-6 text-funeral-medium/40 animate-wiggle-slow hidden md:block" size={44} />
      <Sparkle className="absolute bottom-10 right-10 text-funeral-medium/30 animate-wiggle-slow2 hidden md:block" size={40} />
      {/* Wave shape decor */}
      <svg className="absolute -bottom-16 left-0 w-64 md:w-96 opacity-10 animate-wiggle-slow" viewBox="0 0 300 88" fill="none">
        <path d="M0 88 Q100 0 300 88" stroke="#E6DED1" strokeWidth="5" fill="none"/>
      </svg>
    </div>
  </section>
);

export default HeroPortfolio;
