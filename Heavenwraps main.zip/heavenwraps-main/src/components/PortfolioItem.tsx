
import React from 'react';
import FadeInSection from '@/components/FadeInSection';
import AnimatedServiceCard from '@/components/AnimatedServiceCard';

interface PortfolioItemProps {
  item: {
    id: number;
    title: string;
    description: string;
    image: string;
    price: string;
    type: string;
    isComingSoon: boolean;
  };
  index: number;
}

const PortfolioItem: React.FC<PortfolioItemProps> = ({ item, index }) => {
  // Lagere delays voor de eerste items
  const baseDelay = index < 2 ? 0 : Math.max(0, (index - 2) * 150);
  
  // Create more varied animation patterns
  const animationType = index % 4 === 0 ? 'animate-scale-in hover-tech-lift' : 
                       index % 4 === 1 ? 'animate-fade-in-up hover-magnetic' : 
                       index % 4 === 2 ? 'animate-fade-in hover-neon-glow' :
                       'animate-liquid-morph hover-hologram';

  return (
    <FadeInSection key={item.id} delay={baseDelay}>
      <div className={`${animationType} transition-all duration-700 transform perspective-1000`} 
           style={{ animationDelay: `${baseDelay}ms` }}>
        <div className="relative group">
          {/* Tech Glow Border Effect */}
          <div className="absolute -inset-1 bg-gradient-to-r from-funeral-medium/20 via-funeral-accent/30 to-funeral-dark/20 rounded-lg opacity-0 group-hover:opacity-100 group-hover:animate-tech-glow transition-all duration-500"></div>
          
          {/* Cyber Scan Lines */}
          <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-funeral-accent/70 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-cyber-scan"></div>
          <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-funeral-medium/50 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-cyber-scan" style={{animationDelay: '0.5s'}}></div>
          
          <AnimatedServiceCard
            title={item.title}
            description={item.description}
            price={item.price}
            image={item.image}
            additionalInfo={item.type}
            isComingSoon={item.isComingSoon}
          />
          
          {/* Digital Corner Accents */}
          <div className="absolute top-2 left-2 w-3 h-3 border-l-2 border-t-2 border-funeral-accent/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="absolute top-2 right-2 w-3 h-3 border-r-2 border-t-2 border-funeral-accent/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="absolute bottom-2 left-2 w-3 h-3 border-l-2 border-b-2 border-funeral-accent/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="absolute bottom-2 right-2 w-3 h-3 border-r-2 border-b-2 border-funeral-accent/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        </div>
      </div>
    </FadeInSection>
  );
};

export default PortfolioItem;
