
import React from 'react';
import MailerLiteContactForm from './MailerLiteContactForm';

const ContactForm = () => {
  console.log('ContactForm component rendering with MailerLite integration');
  
  return (
    <div className="relative group">
      {/* Tech Frame */}
      <div className="absolute -inset-2 bg-gradient-to-r from-funeral-accent/20 via-transparent to-funeral-medium/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-500 animate-tech-glow"></div>
      
      <div className="relative bg-white/95 backdrop-blur-sm rounded-2xl border border-funeral-accent/20 hover:border-funeral-accent/40 transition-all duration-500 hover-tech-lift overflow-hidden">
        <MailerLiteContactForm />
      </div>
    </div>
  );
};

export default ContactForm;
