
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Mail, Phone, Send } from 'lucide-react';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { sendContactForm } from "@/api/sendContactForm";
import { sendToMakeWebhook } from "@/api/makeWebhook";

const formSchema = z.object({
  name: z.string()
    .min(2, "Naam moet minimaal 2 tekens bevatten")
    .max(100, "Naam mag maximaal 100 tekens bevatten")
    .regex(/^[a-zA-Z\s\-\.]+$/, "Naam mag alleen letters, spaties, streepjes en punten bevatten"),
  email: z.string()
    .email("Voer een geldig e-mailadres in")
    .max(254, "E-mailadres is te lang"),
  phone: z.string()
    .regex(/^[\+]?[\d\s\-\(\)]+$/, "Ongeldig telefoonnummer format")
    .max(20, "Telefoonnummer is te lang")
    .optional()
    .or(z.literal("")),
  message: z.string()
    .min(10, "Bericht moet minimaal 10 tekens bevatten")
    .max(2000, "Bericht mag maximaal 2000 tekens bevatten"),
});

const HomeContactForm = () => {
  const { toast } = useToast();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
    },
  });

  const [isLoading, setIsLoading] = React.useState(false);

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    
    try {
      const sanitizedValues = {
        name: values.name.trim(),
        email: values.email.trim().toLowerCase(),
        phone: values.phone?.trim(),
        message: values.message.trim(),
      };

      await sendContactForm({
        name: sanitizedValues.name,
        email: sanitizedValues.email,
        phone: sanitizedValues.phone || undefined,
        message: sanitizedValues.message,
        service: undefined,
      });

      // Send to Make.com webhook
      try {
        await sendToMakeWebhook(sanitizedValues);
      } catch (makeError) {
        console.warn('Make.com webhook failed but form was sent:', makeError);
      }
      
      toast({
        title: "Bericht verzonden",
        description: "Uw bericht is succesvol verstuurd! Wij nemen spoedig contact met u op.",
      });
      
      form.reset();
    } catch (err: any) {
      console.error('Form submission error:', err);
      toast({
        title: "Fout bij verzenden",
        description: err.message || "Er is iets misgegaan bij het verzenden. Probeer het later opnieuw.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-xl font-heading font-medium mb-4 text-funeral-dark">Stuur ons een bericht</h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Naam</FormLabel>
                      <FormControl>
                        <Input placeholder="Uw naam" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Telefoon</FormLabel>
                      <FormControl>
                        <Input placeholder="06-12345678" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>E-mail</FormLabel>
                    <FormControl>
                      <Input placeholder="uw.email@voorbeeld.nl" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bericht</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Schrijf hier uw bericht..." 
                        className="min-h-[120px]" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button 
                type="submit" 
                className="w-full bg-funeral-black hover:bg-funeral-black/90 text-white flex items-center gap-2"
                disabled={isLoading}
              >
                <Send size={16} />{isLoading ? "Versturen..." : "Verstuur bericht"}
              </Button>
            </form>
          </Form>
        </div>
        
        <div className="flex flex-col justify-between">
          <div>
            <h3 className="text-xl font-heading font-medium mb-4 text-funeral-dark">Contactgegevens</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="mr-3 mt-1">
                  <Mail className="h-5 w-5 text-funeral-dark" />
                </div>
                <div>
                  <p className="font-medium text-funeral-dark">E-mail</p>
                  <a href="mailto:info@heavenwraps.nl" className="text-funeral-text hover:text-funeral-dark transition-colors">
                    info@heavenwraps.nl
                  </a>
                </div>
              </div>
              <div className="flex items-start">
                <div className="mr-3 mt-1">
                  <Phone className="h-5 w-5 text-funeral-dark" />
                </div>
                <div>
                  <p className="font-medium text-funeral-dark">Telefoon</p>
                  <a href="tel:0201234567" className="text-funeral-text hover:text-funeral-dark transition-colors">
                    020-123 45 67
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-8 p-6 bg-funeral-offwhite rounded-lg">
            <h4 className="font-heading font-medium mb-3 text-funeral-dark">Spoedgeval?</h4>
            <p className="text-funeral-text mb-4">
              Wij begrijpen dat sommige situaties urgent zijn. Voor spoedgevallen zijn wij 24/7 telefonisch bereikbaar.
            </p>
            <Button asChild className="bg-funeral-black hover:bg-funeral-black/90 text-white">
              <a href="tel:0201234567">Direct bellen</a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeContactForm;
