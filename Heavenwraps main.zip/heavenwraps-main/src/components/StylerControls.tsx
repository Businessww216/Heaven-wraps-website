
import React from 'react';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Palette } from 'lucide-react';

interface StylerControlsProps {
  style: string;
  setStyle: (style: string) => void;
}

const StylerControls: React.FC<StylerControlsProps> = ({
  style,
  setStyle
}) => {
  const styles = [
    {
      id: 'classic',
      name: 'Klassiek',
      description: 'Traditionele en tijdloze designs',
      icon: '🏛️'
    },
    {
      id: 'modern',
      name: 'Modern',
      description: 'Strak en eigentijds',
      icon: '✨'
    },
    {
      id: 'natural',
      name: 'Natuurlijk',
      description: 'Natuur en organische elementen',
      icon: '🌿'
    },
    {
      id: 'artistic',
      name: 'Artistiek',
      description: 'Creatief en expressief',
      icon: '🎨'
    }
  ];

  return (
    <div className="relative group">
      {/* Main Container */}
      <div className="relative bg-white/95 rounded-xl shadow-lg p-6 border border-funeral-accent/20 hover-tech-lift transition-all duration-500">
        {/* Tech Corner Accents */}
        <div className="absolute top-3 left-3 w-4 h-4 border-l-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-tech-glow"></div>
        <div className="absolute top-3 right-3 w-4 h-4 border-r-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-tech-glow"></div>
        
        {/* Floating Energy Orb */}
        <div className="absolute top-4 right-4 w-2 h-2 bg-funeral-accent/50 rounded-full opacity-0 group-hover:opacity-100 animate-quantum-float"></div>
        
        <Label className="text-lg font-heading font-semibold text-funeral-dark mb-4 block relative">
          <span className="flex items-center">
            <Palette className="w-5 h-5 mr-2 animate-tech-glow" />
            Kies een AI stijl
          </span>
          {/* Neon Underline */}
          <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-funeral-accent to-funeral-medium group-hover:w-full transition-all duration-500"></div>
        </Label>
        
        <div className="grid grid-cols-1 gap-3">
          {styles.map((styleOption) => (
            <Card
              key={styleOption.id}
              className={`p-4 cursor-pointer transition-all duration-300 border-2 relative group/card overflow-hidden ${
                style === styleOption.id
                  ? 'border-funeral-accent bg-gradient-to-br from-funeral-accent/10 to-funeral-light/30'
                  : 'border-funeral-medium/30 hover:border-funeral-accent/60 bg-white'
              }`}
              onClick={() => setStyle(styleOption.id)}
            >
              {/* Tech Corner Accents for Selected */}
              {style === styleOption.id && (
                <>
                  <div className="absolute top-1 left-1 w-3 h-3 border-l-2 border-t-2 border-funeral-accent/80 animate-tech-glow"></div>
                  <div className="absolute top-1 right-1 w-3 h-3 border-r-2 border-t-2 border-funeral-accent/80 animate-tech-glow"></div>
                  <div className="absolute bottom-1 left-1 w-3 h-3 border-l-2 border-b-2 border-funeral-accent/80 animate-tech-glow"></div>
                  <div className="absolute bottom-1 right-1 w-3 h-3 border-r-2 border-b-2 border-funeral-accent/80 animate-tech-glow"></div>
                </>
              )}
              
              {/* Floating Quantum Node */}
              <div className="absolute top-2 right-2 w-1.5 h-1.5 bg-funeral-accent/50 rounded-full opacity-0 group-hover/card:opacity-100 animate-quantum-float"></div>
              
              <div className="relative z-10 flex items-center space-x-3">
                {/* Icon */}
                <div className="text-2xl relative group/icon">
                  <span className="block group-hover/icon:animate-quantum-float">{styleOption.icon}</span>
                  {style === styleOption.id && (
                    <div className="absolute inset-0 bg-funeral-accent/10 rounded-full blur-sm animate-pulse-gentle"></div>
                  )}
                </div>
                
                <div className="flex-1">
                  <h4 className={`font-heading font-semibold mb-1 transition-all duration-300 ${
                    style === styleOption.id 
                      ? 'text-funeral-dark' 
                      : 'text-funeral-dark group-hover/card:text-funeral-black'
                  }`}>
                    {styleOption.name}
                  </h4>
                  <p className={`text-sm transition-all duration-300 ${
                    style === styleOption.id 
                      ? 'text-funeral-text' 
                      : 'text-funeral-text group-hover/card:text-funeral-dark'
                  }`}>
                    {styleOption.description}
                  </p>
                </div>
                
                {/* Selection Indicator */}
                {style === styleOption.id && (
                  <div className="w-3 h-3 bg-funeral-accent rounded-full animate-tech-glow relative">
                    <div className="absolute inset-0 bg-funeral-accent rounded-full animate-ping opacity-30"></div>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
        
        {/* AI Style Hint */}
        <div className="mt-4 p-3 bg-gradient-to-r from-funeral-light/40 to-funeral-sandstone/30 rounded-lg border border-funeral-accent/20 relative overflow-hidden">
          <p className="text-xs text-funeral-text text-center relative z-10">
            <span className="font-medium">AI Tip:</span> Elke stijl gebruikt unieke algoritmes voor optimale resultaten
          </p>
        </div>
      </div>
    </div>
  );
};

export default StylerControls;
