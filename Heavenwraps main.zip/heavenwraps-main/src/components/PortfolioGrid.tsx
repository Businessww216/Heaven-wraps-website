
import React from 'react';
import PortfolioItem from '@/components/PortfolioItem';
import { gerapteKistenExamples } from '@/data/portfolioData';

const PortfolioGrid: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 md:gap-12 lg:gap-16 mb-20 md:mb-24 lg:mb-28">
      {gerapteKistenExamples.map((item, index) => (
        <PortfolioItem key={item.id} item={item} index={index} />
      ))}
    </div>
  );
};

export default PortfolioGrid;
