
import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const handleBrochureDownload = () => {
    const link = document.createElement('a');
    link.href = 'https://drive.google.com/uc?export=download&id=1YsD8Kl2CZBh_3bJigmUGv5mRQSnaMA3M';
    link.download = 'Heaven-Wraps-Brochure.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <footer className="bg-funeral-white border-t border-funeral-sandstone/20 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-heading font-medium text-funeral-black mb-4">Heaven wraps</h3>
            <p className="text-funeral-text">
              Persoonlijke uitvaartkisten – Uniek gewrapt met liefde en respect
            </p>
          </div>
          
          <div>
            <h3 className="text-xl font-heading font-medium text-funeral-black mb-4">Contact</h3>
            <address className="not-italic text-funeral-text">
              <p>Hoofdstraat 123</p>
              <p>1234 AB Amsterdam</p>
              <p className="mt-2">Tel: 020-123 45 67</p>
              <p>E-mail: info@heavenwraps.nl</p>
            </address>
          </div>
          
          <div>
            <h3 className="text-xl font-heading font-medium text-funeral-black mb-4">Snelkoppelingen</h3>
            <nav className="flex flex-col space-y-2">
              <Link to="/" className="text-funeral-text hover:text-funeral-black transition-colors">Home</Link>
              <Link to="/contact" className="text-funeral-text hover:text-funeral-black transition-colors">Contact</Link>
              <button 
                onClick={handleBrochureDownload}
                className="text-funeral-text hover:text-funeral-black transition-colors text-left"
              >
                Download Brochure
              </button>
            </nav>
          </div>
        </div>
        
        <div className="border-t border-funeral-sandstone/20 mt-8 pt-6 text-center text-funeral-text text-sm">
          <p>&copy; {new Date().getFullYear()} Heaven wraps. Alle rechten voorbehouden.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
