
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ShieldCheck, Zap, Palette, RefreshCw } from 'lucide-react';
import { useState } from 'react';

const Hero = () => {
  const [imageTimestamp, setImageTimestamp] = useState(Date.now());
  
  const reloadImage = () => {
    setImageTimestamp(Date.now());
  };

  return (
    <div className="relative pb-8 md:pb-16">
      <div className="bg-funeral-light overflow-hidden rounded-xl">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 p-6 md:p-12 flex flex-col justify-center">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-serif font-medium mb-4 text-funeral-dark">
              Persoonlijke uitvaartkisten
            </h1>
            <p className="text-xl md:text-2xl font-serif text-funeral-dark mb-2">
              Uniek gewrapt met liefde en respect
            </p>
            <p className="mb-8 text-funeral-text">
              Een bijzonder afscheid met een uitvaartkist die het verhaal vertelt van uw dierbare. 
              Professioneel, snel en volledig naar wens.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild className="bg-funeral-medium hover:bg-funeral-dark text-funeral-text hover:text-white">
                <Link to="/portfolio">Bekijk ons portfolio</Link>
              </Button>
              <Button variant="outline" asChild className="border border-funeral-medium hover:bg-funeral-light text-funeral-dark">
                <Link to="/contact">Neem contact op</Link>
              </Button>
            </div>
          </div>
          <div className="w-full md:w-1/2 p-6">
            <div className="overflow-hidden rounded-lg flex justify-center relative">
              <img
                src={`/lovable-uploads/a80785bf-7ba7-48d2-a29f-ae283135a9f9.png?t=${imageTimestamp}`}
                alt="Elegante uitvaartkist met geometrisch houtmotief – Heaven Wraps premium design"
                className="w-3/4 h-auto object-cover rounded-lg shadow-md transform transition-transform duration-300 hover:scale-105"
                onError={() => reloadImage()}
                loading="lazy"
              />
              <button 
                onClick={reloadImage}
                className="absolute bottom-2 right-2 bg-white/80 p-2 rounded-full shadow-md hover:bg-white transition-colors"
                title="Afbeelding vernieuwen"
              >
                <RefreshCw size={16} className="text-funeral-dark" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Feature cards section */}
      <div className="mt-12 md:mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          {
            icon: <ShieldCheck size={24} className="text-funeral-medium" />,
            title: "Professioneel vakmanschap",
            description: "Ervaren ontwerpers en wrappers zorgen voor een perfect resultaat."
          },
          {
            icon: <Zap size={24} className="text-funeral-medium" />,
            title: "Snelle levering",
            description: "Binnen 24 tot 72 uur geleverd, afhankelijk van uw wensen."
          },
          {
            icon: <Palette size={24} className="text-funeral-medium" />,
            title: "Uniek en creatief",
            description: "Elk ontwerp is maatwerk en volledig gepersonaliseerd."
          }
        ].map((item, index) => (
          <div key={index} className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <div className="flex flex-col items-center text-center">
              <div className="mb-3 bg-funeral-offwhite p-3 rounded-full">
                {item.icon}
              </div>
              <h3 className="text-xl font-serif font-medium mb-3 text-funeral-dark">{item.title}</h3>
              <p className="text-funeral-text">{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Hero;
