
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Send, Zap, Settings, Shield, Lock } from 'lucide-react';
import { storeWebhookUrlSecurely, getWebhookUrlSecurely } from '@/utils/secureWebhookUtils';

interface WebhookData {
  timestamp: string;
  source: string;
  type: string;
  data: any;
}

const WebhookIntegration = () => {
  const { toast } = useToast();
  const [webhookUrl, setWebhookUrl] = useState(() => {
    return getWebhookUrlSecurely() || 'https://hook.eu2.make.com/nkjps40n9erww0k8kr1yxma5p80sd325';
  });
  const [isLoading, setIsLoading] = useState(false);

  const validateWebhookUrl = (url: string): boolean => {
    try {
      const parsedUrl = new URL(url);
      const trustedDomains = [
        'make.com',
        'zapier.com',
        'hook.eu1.make.com',
        'hook.eu2.make.com',
        'hook.us1.make.com',
        'hook.us2.make.com',
        'hooks.zapier.com',
        'webhook.site'
      ];
      
      return parsedUrl.protocol === 'https:' && 
             trustedDomains.some(domain => 
               parsedUrl.hostname === domain || parsedUrl.hostname.endsWith('.' + domain)
             );
    } catch {
      return false;
    }
  };

  const handleTestWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!webhookUrl) {
      toast({
        title: "Webhook URL vereist",
        description: "Voer eerst je Make.com of Zapier webhook URL in.",
        variant: "destructive"
      });
      return;
    }

    if (!validateWebhookUrl(webhookUrl)) {
      toast({
        title: "Ongeldige webhook URL",
        description: "Alleen HTTPS URLs van vertrouwde providers zijn toegestaan.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      const testData: WebhookData = {
        timestamp: new Date().toISOString(),
        source: "Heaven Wraps Website",
        type: "test",
        data: {
          message: "Beveiligde test webhook van Heaven Wraps",
          test: true,
          securityVersion: "2.0"
        }
      };

      await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "HeavenWraps-Webhook/2.0",
          "X-Webhook-Source": "heaven-wraps.nl",
          "X-Security-Version": "2.0"
        },
        mode: "no-cors",
        body: JSON.stringify(testData),
      });

      toast({
        title: "Test verzonden",
        description: "Beveiligde test data is naar je webhook gestuurd. Check je Make.com/Zapier scenario.",
      });
    } catch (error) {
      toast({
        title: "Test mislukt",
        description: "Kon beveiligde test niet verzenden. Controleer je webhook URL.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveWebhook = () => {
    if (!webhookUrl) return;
    
    if (!validateWebhookUrl(webhookUrl)) {
      toast({
        title: "Ongeldige webhook URL",
        description: "Alleen HTTPS URLs van vertrouwde providers zijn toegestaan.",
        variant: "destructive"
      });
      return;
    }

    const success = storeWebhookUrlSecurely(webhookUrl);
    
    if (success) {
      toast({
        title: "Webhook beveiligd opgeslagen",
        description: "Je webhook URL is versleuteld opgeslagen en wordt gebruikt voor contactformulier submissions.",
      });
    } else {
      toast({
        title: "Fout bij opslaan",
        description: "Kon webhook URL niet veilig opslaan.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-funeral-accent to-funeral-medium flex items-center justify-center">
          <Settings className="text-funeral-dark" size={20}/>
        </div>
        <h3 className="text-xl font-heading font-medium text-funeral-dark">Beveiligde Webhook Integratie</h3>
      </div>
      
      <div className="flex items-center gap-2 mb-4 p-3 bg-green-50 rounded-lg border border-green-200">
        <Shield size={16} className="text-green-600" />
        <p className="text-sm text-green-800">
          <strong>Enhanced Security:</strong> URLs worden versleuteld opgeslagen, rate limiting actief, en alleen vertrouwde platforms toegestaan.
        </p>
      </div>
      
      <p className="text-funeral-text mb-6">
        Verbind je website veilig met Make.com of Zapier. Alle webhook URLs worden versleuteld opgeslagen 
        en contactformulier data wordt beveiligd verzonden naar je scenario.
      </p>

      <form onSubmit={handleTestWebhook} className="space-y-4">
        <div>
          <label htmlFor="webhook-url" className="block text-funeral-dark font-medium mb-2">
            <Lock size={16} className="inline mr-2" />
            Beveiligde Make.com of Zapier Webhook URL
          </label>
          <Input
            id="webhook-url"
            type="url"
            placeholder="https://hook.eu1.make.com/... of https://hooks.zapier.com/..."
            value={webhookUrl}
            onChange={(e) => setWebhookUrl(e.target.value)}
            className="w-full"
          />
          <p className="text-sm text-funeral-text mt-1">
            Maak een scenario in Make.com met een Webhook module of een Zap in Zapier met een Webhook trigger.
          </p>
        </div>

        <div className="flex gap-3">
          <Button 
            type="submit" 
            variant="outline"
            className="flex items-center gap-2"
            disabled={isLoading || !webhookUrl}
          >
            <Send size={16} />
            {isLoading ? "Testen..." : "Beveiligde Test"}
          </Button>
          
          <Button 
            type="button"
            className="flex items-center gap-2 bg-funeral-medium hover:bg-funeral-dark"
            onClick={handleSaveWebhook}
            disabled={!webhookUrl}
          >
            <Lock size={16} />
            Versleuteld Opslaan
          </Button>
        </div>
      </form>

      <div className="mt-6 p-4 bg-funeral-offwhite rounded-lg">
        <h4 className="font-medium text-funeral-dark mb-2 flex items-center gap-2">
          <Shield size={16} />
          Enhanced Beveiligingsmaatregelen
        </h4>
        <ul className="text-sm text-funeral-text space-y-1 list-disc list-inside">
          <li>Webhook URLs worden versleuteld opgeslagen in localStorage</li>
          <li>Enhanced rate limiting met progressieve blokkering</li>
          <li>Strikte input sanitization en XSS preventie</li>
          <li>CSRF-achtige protectie met client fingerprinting</li>
          <li>Uitgebreide domain whitelist validatie</li>
          <li>Security headers en content type validatie</li>
        </ul>
      </div>

      <div className="mt-4 p-4 bg-funeral-offwhite rounded-lg">
        <h4 className="font-medium text-funeral-dark mb-2">Hoe werkt het?</h4>
        <ol className="text-sm text-funeral-text space-y-1 list-decimal list-inside">
          <li>Maak een scenario in Make.com of een Zap in Zapier</li>
          <li>Voeg een Webhook trigger/module toe</li>
          <li>Kopieer de webhook URL en plak deze hierboven</li>
          <li>Test de beveiligde verbinding</li>
          <li>Sla versleuteld op - contactformulieren sturen nu veilig data!</li>
        </ol>
      </div>
    </div>
  );
};

export default WebhookIntegration;
