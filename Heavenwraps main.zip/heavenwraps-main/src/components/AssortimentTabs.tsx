
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AnimatedServiceCard from '@/components/AnimatedServiceCard';
import { assortmentItems, categoryNames } from '@/data/AssortimentData';

const AssortimentTabs = () => {
  return (
    <div className="relative max-w-6xl mx-auto">
      {/* Tech Glow Border */}
      <div className="absolute -inset-2 bg-gradient-to-r from-funeral-medium/20 via-funeral-accent/30 to-funeral-dark/20 rounded-2xl opacity-60 animate-tech-glow"></div>
      
      <Tabs defaultValue="basis" className="w-full my-12 glassmorphism rounded-2xl p-6 relative z-10">
        {/* Tech Grid Overlay */}
        <div className="absolute inset-0 tech-grid opacity-20 rounded-2xl pointer-events-none"></div>
        
        <TabsList className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 mb-8 bg-funeral-offwhite/80 backdrop-blur-sm relative z-10">
          {categoryNames.map(cat => (
            <TabsTrigger 
              key={cat.value} 
              value={cat.value}
              className="text-sm md:text-base font-medium transition-all duration-300 hover:bg-funeral-light data-[state=active]:bg-funeral-medium data-[state=active]:text-white"
            >
              {cat.label}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {Object.entries(assortmentItems).map(([category, items]) => (
          <TabsContent key={category} value={category} className="animate-fade-in relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 md:gap-12">
              {items.map((item, idx) => {
                // Create varied animation patterns
                const animationType = idx % 3 === 0 ? 'hover-tech-lift' : idx % 3 === 1 ? 'hover-magnetic' : 'hover-hologram';
                return (
                  <div 
                    key={item.id} 
                    className={`${animationType} transition-all duration-700 transform perspective-1000 relative group`} 
                    style={{
                      animationDelay: `${idx * 150}ms`
                    }}
                  >
                    {/* Digital Corner Accents */}
                    <div className="absolute top-2 left-2 w-4 h-4 border-l-2 border-t-2 border-funeral-accent/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
                    <div className="absolute top-2 right-2 w-4 h-4 border-r-2 border-t-2 border-funeral-accent/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
                    <div className="absolute bottom-2 left-2 w-4 h-4 border-l-2 border-b-2 border-funeral-accent/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
                    <div className="absolute bottom-2 right-2 w-4 h-4 border-r-2 border-b-2 border-funeral-accent/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
                    
                    {/* Cyber Scan Lines */}
                    <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-funeral-accent/70 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-cyber-scan"></div>
                    
                    <AnimatedServiceCard 
                      delay={idx * 120 + 100} 
                      title={item.title} 
                      description={item.description} 
                      price={item.price} 
                      image={
                        // Eerste item in basis krijgt eerdere upload, derde item krijgt deze upload
                        category === "basis" && idx === 0 
                          ? "/lovable-uploads/04eba7ca-6d0e-4ac3-979c-435f1be686eb.png" 
                          : category === "basis" && idx === 2 
                          ? "/lovable-uploads/70b100a0-131b-45cc-bc21-3e89e68e81b7.png" 
                          : item.image
                      } 
                      additionalInfo={item.type} 
                    />
                  </div>
                );
              })}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default AssortimentTabs;
