
import React from "react";
import { Sparkle } from "lucide-react";

const HeroServices: React.FC = () => (
  <section className="relative bg-gradient-to-br from-funeral-sandstone via-funeral-offwhite to-funeral-white py-12 md:py-20 mb-8 overflow-hidden animate-fade-in-slow">
    <div className="container mx-auto px-4 flex flex-col gap-5 items-center justify-center text-center">
      <span className="inline-flex items-center gap-2 text-funeral-dark text-xl font-heading font-bold opacity-90 animate-fade-in [animation-delay:200ms]">
        <Sparkle className="text-funeral-medium animate-wiggle-slow2" size={28} />
        Ontdek onze mogelijkheden
      </span>
      <h1 className="text-3xl sm:text-4xl md:text-5xl font-heading font-semibold mb-2 text-funeral-dark drop-shadow animate-fade-in [animation-delay:300ms]">
        Maak elk afscheid uniek
      </h1>
      <p className="text-xl md:text-2xl text-funeral-text mb-2 max-w-2xl mx-auto animate-fade-in [animation-delay:400ms]">
        Van kleurrijke wraps tot een persoonlijk ontwerp — wij maken elke uitvaartkist bijzonder, met liefde en aandacht.
      </p>
    </div>
    {/* Sierlijke golf achtergrond */}
    <svg className="absolute -bottom-12 left-0 w-64 md:w-96 opacity-10 animate-wiggle-slow" viewBox="0 0 300 88" fill="none">
      <path d="M0 88 Q100 0 300 88" stroke="#E6DED1" strokeWidth="4" fill="none"/>
    </svg>
  </section>
);

export default HeroServices;
