
import React from 'react';
import { Calculator, Euro } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface BundleItem {
  name: string;
  price: number;
  selected: boolean;
}

interface BundleCalculatorProps {
  items: BundleItem[];
  onToggleItem: (index: number) => void;
}

const BundleCalculator: React.FC<BundleCalculatorProps> = ({ items, onToggleItem }) => {
  const totalPrice = items
    .filter(item => item.selected)
    .reduce((sum, item) => sum + item.price, 0);

  const savings = items.length > 1 ? Math.round(totalPrice * 0.1) : 0;
  const finalPrice = totalPrice - savings;

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-funeral-dark">
          <Calculator className="h-5 w-5" />
          Bundel Calculator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          {items.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={item.selected}
                  onChange={() => onToggleItem(index)}
                  className="rounded border-funeral-medium text-funeral-accent focus:ring-funeral-accent"
                />
                <span className={`text-sm ${item.selected ? 'text-funeral-dark' : 'text-funeral-text'}`}>
                  {item.name}
                </span>
              </label>
              <span className="text-sm font-medium text-funeral-dark">
                €{item.price}
              </span>
            </div>
          ))}
        </div>

        {items.filter(item => item.selected).length > 0 && (
          <div className="border-t border-funeral-light pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>Subtotaal:</span>
              <span>€{totalPrice}</span>
            </div>
            {savings > 0 && (
              <div className="flex justify-between text-sm text-green-600">
                <span>Bundel korting (10%):</span>
                <span>-€{savings}</span>
              </div>
            )}
            <div className="flex justify-between font-semibold text-funeral-dark border-t border-funeral-light pt-2">
              <span className="flex items-center gap-1">
                <Euro className="h-4 w-4" />
                Totaal:
              </span>
              <span>€{finalPrice}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default BundleCalculator;
