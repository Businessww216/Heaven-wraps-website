
import React from 'react';
import MailerLiteFormStyles from './MailerLiteFormStyles';
import MailerLiteForm from './MailerLiteForm';
import MailerLiteFormScripts from './MailerLiteFormScripts';

const MailerLiteContactForm = () => {
  return (
    <>
      <MailerLiteFormStyles />
      <MailerLiteForm />
      <MailerLiteFormScripts />
    </>
  );
};

export default MailerLiteContactForm;
