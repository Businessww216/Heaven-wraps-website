
import React from "react";
import { User, Palette, Cog, Truck } from "lucide-react";

interface ServiceStepProps {
  step: number;
  title: string;
  description: string;
  delay?: number;
}

const icons = [<User size={28} />, <Palette size={28} />, <Cog size={28} />, <Truck size={28} />];

const ServiceStep: React.FC<ServiceStepProps> = ({ step, title, description, delay = 0 }) => (
  <div className="flex items-start group">
    <div className="mr-6 relative">
      <div className="w-12 h-12 rounded-full bg-funeral-medium flex items-center justify-center shadow-md border-2 border-funeral-light animate-wiggle-on-hover transition-shadow group-hover:shadow-lg">
        <span className="text-xl font-medium text-funeral-dark">{icons[step - 1]}</span>
      </div>
      {/* Verticale lijn behalve bij de laatste stap */}
      {step < 4 && (
        <div className="absolute left-1/2 -translate-x-1/2 top-12 w-1 h-16 bg-funeral-sandstone z-0"></div>
      )}
    </div>
    <div>
      <h3 className="text-xl font-serif font-medium mb-2 text-funeral-dark">{title}</h3>
      <p className="text-funeral-text">{description}</p>
    </div>
  </div>
);

export default ServiceStep;
