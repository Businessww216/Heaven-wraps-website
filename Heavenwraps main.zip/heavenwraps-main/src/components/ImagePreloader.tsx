
import { useEffect } from 'react';

interface ImagePreloaderProps {
  images: string[];
  priority?: boolean;
}

const ImagePreloader: React.FC<ImagePreloaderProps> = ({ images, priority = false }) => {
  useEffect(() => {
    const preloadImages = () => {
      images.forEach((src) => {
        const link = document.createElement('link');
        link.rel = priority ? 'preload' : 'prefetch';
        link.as = 'image';
        link.href = src;
        document.head.appendChild(link);
      });
    };

    // Preload immediately for priority images, or after a delay for others
    if (priority) {
      preloadImages();
    } else {
      const timer = setTimeout(preloadImages, 1000);
      return () => clearTimeout(timer);
    }
  }, [images, priority]);

  return null;
};

export default ImagePreloader;
