
import React from 'react';

const MailerLiteForm = () => {
  return (
    <div id="mlb2-27509637" className="ml-form-embedContainer ml-subscribe-form ml-subscribe-form-27509637">
      <div className="ml-form-align-center">
        <div className="ml-form-embedWrapper embedForm">
          <div className="ml-form-embedBody ml-form-embedBodyDefault row-form">
            <div className="ml-form-embedContent">
              <h4>Neem contact op</h4>
              <p>Heeft u vragen, of wilt u een persoonlijk gesprek om de mogelijkheden te bespreken? Vul het formulier in en wij nemen spoedig contact met u op.</p>
            </div>

            <form 
              className="ml-block-form" 
              action="https://assets.mailerlite.com/jsonp/1606259/forms/157914115936879838/subscribe" 
              data-code="" 
              method="post" 
              target="_blank"
            >
              <div className="ml-form-formContent">
                <div className="ml-form-fieldRow">
                  <div className="ml-field-group ml-field-name ml-validate-required">
                    <label htmlFor="name-field">Naam *</label>
                    <input 
                      id="name-field"
                      aria-label="name" 
                      aria-required="true" 
                      type="text" 
                      className="form-control" 
                      data-inputmask="" 
                      name="fields[name]" 
                      placeholder="Uw naam" 
                      autoComplete="given-name"
                    />
                  </div>
                </div>

                <div className="ml-form-fieldRow">
                  <div className="ml-field-group ml-field-email ml-validate-email ml-validate-required">
                    <label htmlFor="email-field">E-mail *</label>
                    <input 
                      id="email-field"
                      aria-label="email" 
                      aria-required="true" 
                      type="email" 
                      className="form-control" 
                      data-inputmask="" 
                      name="fields[email]" 
                      placeholder="uw.email@voorbeeld.nl" 
                      autoComplete="email"
                    />
                  </div>
                </div>

                <div className="ml-form-fieldRow ml-last-item">
                  <div className="ml-field-group ml-field-last_name">
                    <label htmlFor="message-field">Bericht *</label>
                    <textarea 
                      id="message-field"
                      className="form-control" 
                      name="fields[last_name]" 
                      aria-label="last_name" 
                      maxLength={2000} 
                      placeholder="Schrijf hier uw bericht..."
                    />
                  </div>
                </div>
              </div>

              <input type="hidden" name="ml-submit" value="1" />

              <div className="ml-form-embedSubmit">
                <button type="submit" className="primary">Verstuur bericht</button>
                <button disabled style={{ display: 'none' }} type="button" className="loading">
                  <div className="ml-form-embedSubmitLoad"></div>
                  <span className="sr-only">Loading...</span>
                </button>
              </div>

              <input type="hidden" name="anticsrf" value="true" />
            </form>
          </div>

          <div className="ml-form-successBody row-success" style={{ display: 'none' }}>
            <div className="ml-form-successContent">
              <h4>Bedankt!</h4>
              <p>Uw bericht is succesvol verstuurd. Wij nemen spoedig contact met u op.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MailerLiteForm;
