import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { sendContactForm } from "@/api/sendContactForm";
import { sendToWebhookSecurely } from "@/utils/webhookUtils";
import { sendToMakeWebhook } from "@/api/makeWebhook";

const formSchema = z.object({
  name: z.string()
    .min(2, "Naam moet minimaal 2 tekens bevatten")
    .max(100, "Naam mag maximaal 100 tekens bevatten")
    .regex(/^[a-zA-Z\s\-\.]+$/, "Naam mag alleen letters, spaties, streepjes en punten bevatten"),
  email: z.string()
    .email("Voer een geldig e-mailadres in")
    .max(254, "E-mailadres is te lang"),
  phone: z.string()
    .regex(/^[\+]?[\d\s\-\(\)]+$/, "Ongeldig telefoonnummer format")
    .max(20, "Telefoonnummer is te lang")
    .optional()
    .or(z.literal("")),
  message: z.string()
    .min(10, "Bericht moet minimaal 10 tekens bevatten")
    .max(2000, "Bericht mag maximaal 2000 tekens bevatten"),
  service: z.enum(['basic', 'custom'])
});

const ContactForm = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  console.log('ContactForm component rendering');
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
      message: '',
      service: 'basic'
    },
  });
  
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    console.log('Form submission started', values);
    setIsLoading(true);
    
    try {
      console.log('Sending contact form...');
      await sendContactForm({
        name: values.name.trim(),
        email: values.email.trim().toLowerCase(),
        phone: values.phone?.trim(),
        message: values.message.trim(),
        service: values.service
      });
      
      console.log('Contact form sent successfully, now sending to secure webhook and Make.com...');
      
      // Send to secure webhook with enhanced error handling
      try {
        const { sendToWebhookSecurely } = await import("@/utils/secureWebhookUtils");
        await sendToWebhookSecurely(values, 'contact-form-submission');
        console.log('Secure webhook sent successfully');
      } catch (webhookError) {
        console.warn('Secure webhook failed but form was sent:', webhookError);
      }

      // Send to Make.com webhook
      try {
        await sendToMakeWebhook({
          name: values.name.trim(),
          email: values.email.trim().toLowerCase(),
          phone: values.phone?.trim(),
          message: values.message.trim(),
          service: values.service
        });
        console.log('Make.com webhook sent successfully');
      } catch (makeError) {
        console.warn('Make.com webhook failed but form was sent:', makeError);
      }
      
      toast({
        title: "Bericht verzonden",
        description: "Uw bericht is succesvol verstuurd. Wij nemen spoedig contact met u op.",
      });
      
      form.reset();
      console.log('Form reset completed');
    } catch (err: any) {
      console.error('Form submission error:', err);
      toast({
        title: "Fout bij verzenden",
        description: err.message || "Er is iets misgegaan bij het verzenden. Probeer het later opnieuw.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      console.log('Form submission completed');
    }
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="bg-white rounded-lg shadow-md p-6 max-w-2xl mx-auto space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Naam *</FormLabel>
              <FormControl>
                <Input placeholder="Uw naam" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>E-mail *</FormLabel>
              <FormControl>
                <Input type="email" placeholder="uw.email@voorbeeld.nl" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="phone"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Telefoonnummer</FormLabel>
              <FormControl>
                <Input type="tel" placeholder="06-12345678" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="service"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Gewenste dienst</FormLabel>
              <FormControl>
                <select
                  {...field}
                  className="w-full px-4 py-2 border border-funeral-medium/30 rounded-md focus:outline-none focus:ring-2 focus:ring-funeral-medium"
                >
                  <option value="basic">Basic</option>
                  <option value="custom">Custom made</option>
                </select>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Bericht *</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Schrijf hier uw bericht..." 
                  className="min-h-[120px]" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <Button 
          type="submit" 
          className="bg-funeral-medium hover:bg-funeral-dark text-funeral-text hover:text-white w-full"
          disabled={isLoading}
        >
          {isLoading ? "Versturen..." : "Verstuur bericht"}
        </Button>
        
        <p className="text-sm text-funeral-text">
          * Verplichte velden. Wij reageren doorgaans binnen 24 uur op uw bericht.
        </p>
      </form>
    </Form>
  );
};

export default ContactForm;
