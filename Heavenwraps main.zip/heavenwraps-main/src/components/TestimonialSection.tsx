
import React from 'react';
import FadeInSection from '@/components/FadeInSection';

const testimonials = [
  {
    quote: "De eenvoudige kist paste perfect bij wie mijn vader was: puur en eerlijk.",
    author: "Familie Smit"
  },
  {
    quote: "Wij wilden een duurzame oplossing en de ecologische kist was prachtig.",
    author: "Familie Brouwer"
  },
  {
    quote: "Mooi assortiment, vriendelijk geholpen en snel geleverd.",
    author: "Familie Janssen"
  },
  {
    quote: "De kale kist bood ons alle ruimte om hem persoonlijk te maken.",
    author: "Familie van Leeuwen"
  }
];

const TestimonialSection = () => {
  return (
    <div className="relative max-w-6xl mx-auto">
      {/* Holographic Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-funeral-light/80 via-funeral-offwhite/90 to-funeral-sandstone/80 backdrop-blur-sm rounded-2xl animate-hologram"></div>
      
      {/* Neon Border Glow */}
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-funeral-accent/20 via-transparent to-funeral-medium/20 animate-tech-glow"></div>
      
      <div className="bg-funeral-light p-10 md:p-12 rounded-2xl my-12 shadow-2xl relative glassmorphism border border-funeral-accent/30">
        {/* Tech Grid Overlay */}
        <div className="absolute inset-0 tech-grid opacity-20 rounded-2xl"></div>
        
        <h2 className="text-3xl md:text-4xl font-heading mb-8 text-funeral-dark text-center relative cyberpunk-text">
          Wat onze klanten zeggen
          {/* Chrome Shine Effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform skew-x-12 opacity-0 hover:opacity-100 hover:animate-chrome-shine"></div>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8 relative z-10">
          {testimonials.map((testimonial, index) => (
            <FadeInSection key={index} delay={index * 120 + 250}>
              <div className="bg-white/90 p-8 rounded-xl shadow-lg hover:shadow-2xl transition-all duration-500 group hover:scale-105 hover-neon-glow relative backdrop-blur-sm border border-funeral-accent/20">
                {/* Floating Energy Orbs */}
                <div className="absolute top-3 right-3 w-1.5 h-1.5 bg-funeral-accent/60 rounded-full opacity-0 group-hover:opacity-100 animate-pulse-gentle group-hover:animate-quantum-float"></div>
                
                <div className="text-funeral-medium text-4xl md:text-5xl mb-6 transition-transform group-hover:scale-110 animate-neon-pulse">"</div>
                <p className="text-funeral-text text-lg md:text-xl italic mb-6 leading-relaxed">{testimonial.quote}</p>
                <p className="text-funeral-dark font-medium text-lg">— {testimonial.author}</p>
              </div>
            </FadeInSection>
          ))}
        </div>
        
        {/* Floating Tech Elements */}
        <div className="absolute top-4 left-4 w-2 h-2 bg-funeral-accent/50 rounded-full animate-pulse-gentle"></div>
        <div className="absolute top-8 right-6 w-1 h-1 bg-funeral-medium/60 rounded-full animate-pulse-gentle" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-6 left-8 w-1.5 h-1.5 bg-funeral-dark/40 rounded-full animate-pulse-gentle" style={{animationDelay: '2s'}}></div>
      </div>
    </div>
  );
};

export default TestimonialSection;
