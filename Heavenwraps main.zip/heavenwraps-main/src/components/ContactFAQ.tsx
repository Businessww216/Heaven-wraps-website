
import React from 'react';
import { Clock } from 'lucide-react';

const ContactFAQ = () => {
  return (
    <div className="relative group">
      <div className="absolute -inset-1 bg-gradient-to-r from-funeral-accent/20 to-funeral-medium/20 rounded-xl blur-lg group-hover:blur-xl transition-all duration-500"></div>
      
      <div className="relative bg-white/95 backdrop-blur-sm p-8 rounded-xl shadow-lg border border-funeral-accent/20 hover:border-funeral-accent/40 transition-all duration-500 hover-tech-lift">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-funeral-accent/80 to-funeral-medium flex items-center justify-center animate-quantum-float">
            <Clock className="text-funeral-dark" size={20}/>
          </div>
          <h3 className="text-xl font-heading font-semibold text-funeral-dark">Veelgestelde vragen</h3>
        </div>
        
        <div className="space-y-3">
          <div className="group/faq hover:bg-funeral-accent/10 p-3 rounded-lg transition-all duration-300 border border-transparent hover:border-funeral-accent/20">
            <p className="font-semibold text-funeral-dark mb-1 group-hover/faq:text-funeral-black">Hoe neem ik contact op voor advies?</p>
            <p className="text-funeral-text text-sm leading-relaxed">Bel ons op 020-123 45 67 of vul het contactformulier in. Voor spoedgevallen zijn wij 24/7 bereikbaar.</p>
          </div>
          
          <div className="group/faq hover:bg-funeral-accent/10 p-3 rounded-lg transition-all duration-300 border border-transparent hover:border-funeral-accent/20">
            <p className="font-semibold text-funeral-dark mb-1 group-hover/faq:text-funeral-black">Werken jullie samen met uitvaartverzorgers?</p>
            <p className="text-funeral-text text-sm leading-relaxed">Ja, we werken samen met alle uitvaartverzorgers in Nederland en stemmen alles met hen af.</p>
          </div>
          
          <div className="group/faq hover:bg-funeral-accent/10 p-3 rounded-lg transition-all duration-300 border border-transparent hover:border-funeral-accent/20">
            <p className="font-semibold text-funeral-dark mb-1 group-hover/faq:text-funeral-black">Wat voor materialen gebruiken jullie?</p>
            <p className="text-funeral-text text-sm leading-relaxed">We gebruiken uitsluitend hoogwaardige, duurzame materialen voor al onze kisten en wrapping designs.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactFAQ;
