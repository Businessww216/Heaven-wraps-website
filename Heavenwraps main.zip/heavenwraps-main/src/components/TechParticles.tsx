
import React, { useEffect, useState } from 'react';

const TechParticles: React.FC = () => {
  const [particles, setParticles] = useState<Array<{ id: number; x: number; delay: number }>>([]);

  useEffect(() => {
    const particleCount = 8; // Reduced from 15 for better performance
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      delay: Math.random() * 10
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="tech-particles">
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="tech-particle"
          style={{
            left: `${particle.x}%`,
            animationDelay: `${particle.delay}s`
          }}
        />
      ))}
    </div>
  );
};

export default TechParticles;
