
import React, { useEffect } from 'react';

const MailerLiteFormScripts = () => {
  useEffect(() => {
    // Load MailerLite webforms script
    const script = document.createElement('script');
    script.src = 'https://groot.mailerlite.com/js/w/webforms.min.js?v176e10baa5e7ed80d35ae235be3d5024';
    script.type = 'text/javascript';
    document.head.appendChild(script);

    // Load tracking script
    const trackingScript = document.createElement('script');
    trackingScript.innerHTML = `
      fetch("https://assets.mailerlite.com/jsonp/1606259/forms/157914115936879838/takel")
    `;
    document.head.appendChild(trackingScript);

    return () => {
      // Cleanup scripts on unmount
      document.head.removeChild(script);
      document.head.removeChild(trackingScript);
    };
  }, []);

  return (
    <script
      dangerouslySetInnerHTML={{
        __html: `
          function ml_webform_success_27509637() {
            var $ = ml_jQuery || jQuery;
            $('.ml-subscribe-form-27509637 .row-success').show();
            $('.ml-subscribe-form-27509637 .row-form').hide();
          }
        `
      }}
    />
  );
};

export default MailerLiteFormScripts;
