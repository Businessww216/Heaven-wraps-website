
import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, Share2, Eye, Sparkles } from 'lucide-react';

interface KistPreviewProps {
  generatedImage: string | null;
  isLoading: boolean;
}

const KistPreview: React.FC<KistPreviewProps> = ({
  generatedImage,
  isLoading
}) => {
  return (
    <div className="relative group">
      {/* Main Container */}
      <div className="relative bg-white/95 rounded-xl shadow-lg p-6 border border-funeral-accent/20 hover-tech-lift transition-all duration-500">
        {/* Tech Corner Accents */}
        <div className="absolute top-3 left-3 w-6 h-6 border-l-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-tech-glow"></div>
        <div className="absolute top-3 right-3 w-6 h-6 border-r-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-tech-glow"></div>
        <div className="absolute bottom-3 left-3 w-6 h-6 border-l-2 border-b-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-tech-glow"></div>
        <div className="absolute bottom-3 right-3 w-6 h-6 border-r-2 border-b-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-tech-glow"></div>
        
        {/* Floating Tech Elements */}
        <div className="absolute top-4 right-4 w-2 h-2 bg-funeral-accent/50 rounded-full opacity-0 group-hover:opacity-100 animate-quantum-float"></div>
        <div className="absolute bottom-4 left-4 w-1.5 h-1.5 bg-funeral-medium/60 rounded-full opacity-0 group-hover:opacity-100 animate-pulse-gentle" style={{animationDelay: '1s'}}></div>
        
        <h3 className="text-lg font-heading font-semibold text-funeral-dark mb-4 relative">
          <span className="flex items-center">
            <Sparkles className="w-5 h-5 mr-2 animate-tech-glow" />
            AI Design Preview
          </span>
        </h3>
        
        {/* Preview Container */}
        <div className="relative aspect-square rounded-lg border-2 border-dashed border-funeral-medium/30 overflow-hidden group/preview bg-funeral-offwhite/30">
          {/* Content */}
          <div className="relative w-full h-full flex items-center justify-center">
            {isLoading ? (
              <div className="text-center relative z-10">
                {/* Loading Animation */}
                <div className="relative mb-6">
                  <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-funeral-accent mx-auto animate-tech-glow"></div>
                  <div className="absolute inset-0 animate-spin rounded-full h-16 w-16 border-r-2 border-funeral-medium mx-auto" style={{animationDirection: 'reverse', animationDelay: '0.5s'}}></div>
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <Sparkles className="w-6 h-6 text-funeral-dark animate-quantum-float" />
                  </div>
                </div>
                <p className="text-funeral-text">
                  <span>AI genereert uw unieke design...</span>
                </p>
                <div className="mt-2 text-xs text-funeral-medium">
                  <span className="animate-pulse-gentle">Quantum processing in progress</span>
                </div>
              </div>
            ) : generatedImage ? (
              <div className="relative w-full h-full group/image">
                <img 
                  src={generatedImage} 
                  alt="AI gegenereerd kist design" 
                  className="w-full h-full object-cover rounded-lg transition-all duration-500 group-hover/image:scale-105 hover-magnetic" 
                />
                {/* Subtle Overlay */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent opacity-0 group-hover/image:opacity-100 transition-opacity duration-300 rounded-lg"></div>
              </div>
            ) : (
              <div className="relative w-full h-full flex items-center justify-center">
                <img 
                  src="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="Coming Soon" 
                  className="w-full h-full object-cover rounded-lg opacity-30"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-funeral-black/40 via-funeral-dark/30 to-funeral-medium/40 rounded-lg"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white relative z-10">
                    <h2 className="text-4xl font-heading font-bold mb-2 text-shadow-lg">Coming Soon</h2>
                    <p className="text-lg text-funeral-white/90 leading-relaxed">
                      AI Design Generator
                    </p>
                    
                    {/* Floating Quantum Nodes */}
                    <div className="absolute top-4 left-4 w-2 h-2 bg-funeral-accent/50 rounded-full animate-quantum-float"></div>
                    <div className="absolute bottom-6 right-6 w-1.5 h-1.5 bg-funeral-sandstone/60 rounded-full animate-pulse-gentle" style={{animationDelay: '1.5s'}}></div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        {generatedImage && (
          <div className="mt-6 flex gap-3">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1 border-2 border-funeral-medium/40 hover:border-funeral-accent bg-white hover:bg-funeral-light/30 text-funeral-dark hover-magnetic group/btn relative overflow-hidden transition-all duration-300"
            >
              {/* Button Background */}
              <div className="absolute inset-0 bg-gradient-to-r from-funeral-accent/5 to-funeral-medium/5 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300"></div>
              <Download className="h-4 w-4 mr-2 group-hover/btn:animate-quantum-float" />
              <span className="relative z-10">Download HD</span>
            </Button>
            
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1 border-2 border-funeral-medium/40 hover:border-funeral-accent bg-white hover:bg-funeral-light/30 text-funeral-dark hover-magnetic group/btn relative overflow-hidden transition-all duration-300"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-funeral-accent/5 to-funeral-medium/5 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300"></div>
              <Share2 className="h-4 w-4 mr-2 group-hover/btn:animate-quantum-float" />
              <span className="relative z-10">Delen</span>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default KistPreview;
