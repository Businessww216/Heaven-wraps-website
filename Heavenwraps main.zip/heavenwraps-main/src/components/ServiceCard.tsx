
import React from 'react';
import { Badge } from '@/components/ui/badge';
import EnhancedImage from '@/components/EnhancedImage';

interface ServiceCardProps {
  title: string;
  description: string;
  price: string;
  additionalInfo?: string;
  image: string;
  isComingSoon?: boolean;
}

const ServiceCard = ({
  title,
  description,
  price,
  additionalInfo,
  image,
  isComingSoon = false
}: ServiceCardProps) => {
  return (
    <div className={`bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-500 relative backdrop-blur-sm border border-funeral-accent/20 ${
      isComingSoon ? 'opacity-70' : 'hover:shadow-2xl'
    }`}>
      <div className="relative h-48 md:h-56">
        {image && (
          <EnhancedImage
            src={image}
            alt={title}
            className={`object-cover w-full h-full transition-all duration-500 ${
              isComingSoon ? 'grayscale' : 'group-hover:scale-105'
            }`}
          />
        )}
        
        {isComingSoon && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center backdrop-blur-sm">
            <Badge variant="secondary" className="bg-white/95 text-funeral-dark font-medium px-6 py-3 text-base animate-pulse-gentle">
              Binnenkort beschikbaar
            </Badge>
          </div>
        )}
        
        {/* Tech Corner Accents */}
        <div className="absolute top-3 left-3 w-4 h-4 border-l-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <div className="absolute top-3 right-3 w-4 h-4 border-r-2 border-t-2 border-funeral-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      </div>
      
      <div className="p-6 md:p-8 relative">
        {/* Floating Energy Orb */}
        <div className="absolute top-4 right-4 w-2 h-2 bg-funeral-accent/50 rounded-full opacity-0 group-hover:opacity-100 animate-pulse-gentle group-hover:animate-quantum-float"></div>
        
        <h3 className="text-lg md:text-xl font-heading font-semibold mb-3 text-funeral-dark leading-tight cyberpunk-text line-clamp-2">
          {title}
        </h3>
        
        <p className="text-funeral-text mb-4 leading-relaxed text-sm md:text-base min-h-[4rem] md:min-h-[4.5rem] line-clamp-3">
          {description}
        </p>
        
        <div className="pt-4 border-t border-funeral-offwhite/60 relative">
          {/* Cyber Scan Line */}
          <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-funeral-accent/50 to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-cyber-scan"></div>
          
          <div className="flex justify-between items-center">
            <p className="text-lg md:text-xl font-heading font-bold text-funeral-dark animate-neon-pulse">
              {isComingSoon ? 'Binnenkort beschikbaar' : price}
            </p>
            
            {additionalInfo && !isComingSoon && (
              <Badge variant="outline" className="border-funeral-medium text-funeral-dark bg-funeral-light/50 px-2 py-1 text-xs font-medium">
                {additionalInfo}
              </Badge>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;
