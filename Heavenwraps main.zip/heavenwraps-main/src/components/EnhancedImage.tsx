
import React, { useState, useEffect } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { RefreshCw } from 'lucide-react';

interface EnhancedImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackSrc?: string;
  showSkeleton?: boolean;
  priority?: boolean;
  onLoad?: () => void;
  onError?: (e: React.SyntheticEvent<HTMLImageElement>) => void;
}

const EnhancedImage: React.FC<EnhancedImageProps> = ({
  src,
  alt,
  className = '',
  fallbackSrc,
  showSkeleton = true,
  priority = false,
  onLoad,
  onError
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [currentSrc, setCurrentSrc] = useState(src);
  const [retryCount, setRetryCount] = useState(0);

  // Create image URL with cache busting
  const createImageUrl = (imageSrc: string, forceRefresh = false) => {
    if (!imageSrc) return '';
    const timestamp = forceRefresh ? `?t=${Date.now()}` : '';
    return `${imageSrc}${timestamp}`;
  };

  useEffect(() => {
    setCurrentSrc(createImageUrl(src));
  }, [src]);

  const handleLoad = () => {
    console.log('Image loaded successfully:', currentSrc);
    setIsLoading(false);
    setHasError(false);
    onLoad?.();
  };

  const handleError = (e: React.SyntheticEvent<HTMLImageElement>) => {
    console.error('Image failed to load:', currentSrc);
    setIsLoading(false);
    
    // Try fallback first
    if (fallbackSrc && currentSrc !== fallbackSrc && retryCount === 0) {
      console.log('Trying fallback image:', fallbackSrc);
      setCurrentSrc(fallbackSrc);
      setRetryCount(1);
      return;
    }
    
    // Retry with cache busting
    if (retryCount < 2) {
      const newRetryCount = retryCount + 1;
      console.log(`Retry attempt ${newRetryCount} for:`, src);
      setRetryCount(newRetryCount);
      setTimeout(() => {
        setCurrentSrc(createImageUrl(src, true));
      }, 1000 * newRetryCount);
      return;
    }

    setHasError(true);
    onError?.(e);
  };

  const handleRetry = () => {
    console.log('Manual retry for:', src);
    setIsLoading(true);
    setHasError(false);
    setRetryCount(0);
    setCurrentSrc(createImageUrl(src, true));
  };

  return (
    <div className="relative">
      {isLoading && showSkeleton && (
        <Skeleton className={`absolute inset-0 ${className}`} />
      )}
      
      <img
        src={currentSrc}
        alt={alt}
        className={`${className} ${isLoading ? 'opacity-0' : 'opacity-100'} transition-opacity duration-300`}
        onLoad={handleLoad}
        onError={handleError}
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
      />
      
      {hasError && (
        <div className={`${className} bg-funeral-light flex flex-col items-center justify-center text-funeral-text text-sm border border-funeral-accent/20 rounded`}>
          <div className="p-4 text-center">
            <p className="mb-2">Afbeelding niet beschikbaar</p>
            <button 
              onClick={handleRetry}
              className="flex items-center gap-1 text-xs text-funeral-medium hover:text-funeral-dark underline"
            >
              <RefreshCw size={12} />
              Opnieuw proberen
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EnhancedImage;
