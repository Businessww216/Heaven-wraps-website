import React, { useState } from 'react';
import { Eye, Play, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const VideoSection = () => {
  const [videoError, setVideoError] = useState(false);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  // Extract file ID from Google Drive URL and convert to embed format
  const videoFileId = '1aX9-C89DyizwSgyi5jlaukdTSKEhi0vM';
  const embedUrl = `https://drive.google.com/file/d/${videoFileId}/preview?t=${Date.now()}`;
  const directUrl = `https://drive.google.com/file/d/${videoFileId}/view`;

  const handleVideoError = () => {
    console.error('Video failed to load:', embedUrl);
    setVideoError(true);
  };

  const handleVideoLoad = () => {
    console.log('Video loaded successfully');
    setIsVideoLoaded(true);
    setVideoError(false);
  };

  const handleRetryVideo = () => {
    console.log('Retrying video load');
    setVideoError(false);
    setIsVideoLoaded(false);
    setRetryCount(prev => prev + 1);
  };

  return (
    <section className="my-16">
      <div className="container mx-auto">
        <h2 className="text-2xl md:text-3xl lg:text-4xl font-heading font-medium text-funeral-black text-center mb-4">
          Een bijzonder afscheid met HEAVEN WRAPS
        </h2>
        
        <div className="mt-8 text-center">
          <p className="text-funeral-text max-w-2xl mx-auto mb-8">
            Zie hoe wij met vakmanschap en respect elke uitvaartkist transformeren tot een persoonlijk en waardig afscheid.
          </p>
        </div>
        
        <div className="relative max-w-4xl mx-auto rounded-xl overflow-hidden shadow-2xl hover:shadow-3xl transition-shadow duration-500 mt-8">
          {/* Video Container */}
          <div className="relative w-full aspect-video bg-funeral-light">
            {!videoError ? (
              <>
                <iframe
                  key={retryCount} // Force re-render on retry
                  src={`${embedUrl}&retry=${retryCount}`}
                  className="w-full h-full rounded-xl"
                  allow="autoplay; encrypted-media"
                  allowFullScreen
                  title="Heaven Wraps Video Presentatie - Een bijzonder afscheid met gepersonaliseerde uitvaartkisten"
                  loading="lazy"
                  onError={handleVideoError}
                  onLoad={handleVideoLoad}
                />
                
                {/* Loading overlay */}
                {!isVideoLoaded && (
                  <div className="absolute inset-0 bg-funeral-light flex items-center justify-center">
                    <div className="text-center">
                      <Play className="w-16 h-16 text-funeral-medium mx-auto mb-4 animate-pulse" />
                      <p className="text-funeral-text">Video wordt geladen...</p>
                    </div>
                  </div>
                )}
              </>
            ) : (
              // Fallback content when video fails to load
              <div className="absolute inset-0 bg-gradient-to-br from-funeral-light to-funeral-offwhite flex items-center justify-center">
                <div className="text-center p-8">
                  <AlertCircle className="w-16 h-16 text-funeral-medium mx-auto mb-4" />
                  <h3 className="text-xl font-heading font-medium mb-4 text-funeral-dark">
                    Video momenteel niet beschikbaar
                  </h3>
                  <p className="text-funeral-text mb-6">
                    Onze video presentatie kan momenteel niet worden geladen. 
                  </p>
                  <div className="flex gap-4 justify-center">
                    <Button 
                      onClick={handleRetryVideo}
                      variant="outline" 
                      className="border-funeral-medium hover:bg-funeral-medium hover:text-white"
                    >
                      <RefreshCw size={20} className="mr-2" />
                      Opnieuw proberen
                    </Button>
                    <Button asChild variant="outline" className="border-funeral-medium hover:bg-funeral-medium hover:text-white">
                      <a 
                        href={directUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2"
                      >
                        <Play size={20} />
                        Video bekijken
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Content Cards Below Video */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-funeral-light rounded-full flex items-center justify-center mb-4">
                <Eye className="w-8 h-8 text-funeral-medium" />
              </div>
              <h3 className="text-xl font-heading font-medium mb-3 text-funeral-dark">
                Vakmanschap
              </h3>
              <p className="text-funeral-text">
                Ervaren ontwerpers zorgen voor een perfect resultaat bij elke uitvaartkist.
              </p>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-funeral-light rounded-full flex items-center justify-center mb-4">
                <svg className="w-8 h-8 text-funeral-medium" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z"/>
                </svg>
              </div>
              <h3 className="text-xl font-heading font-medium mb-3 text-funeral-dark">
                Snelle Service
              </h3>
              <p className="text-funeral-text">
                Binnen 24-72 uur geleverd, precies wanneer u het nodig heeft.
              </p>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-funeral-light rounded-full flex items-center justify-center mb-4">
                <svg className="w-8 h-8 text-funeral-medium" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
              </div>
              <h3 className="text-xl font-heading font-medium mb-3 text-funeral-dark">
                Uniek Design
              </h3>
              <p className="text-funeral-text">
                Elk ontwerp is volledig gepersonaliseerd en vertelt een uniek verhaal.
              </p>
            </div>
          </div>
        </div>
        
        {/* Call to Action */}
        <div className="mt-10 text-center">
          <Button asChild className="bg-funeral-medium hover:bg-funeral-dark text-white font-medium px-8 py-3 rounded-full shadow-lg transition-all duration-300">
            <Link to="/portfolio" className="flex items-center gap-3">
              <Eye size={20} />
              Bekijk ons portfolio
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default VideoSection;
