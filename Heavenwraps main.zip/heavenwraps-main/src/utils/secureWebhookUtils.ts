
export interface WebhookData {
  timestamp: string;
  source: string;
  type: string;
  data: any;
}

// Enhanced encryption for webhook URLs
const ENCRYPTION_KEY = 'heavenwraps-secure-key-2024';

const encryptWebhookUrl = (url: string): string => {
  try {
    // Simple encryption - in production use proper crypto library
    const encoded = btoa(url + '|' + ENCRYPTION_KEY);
    return encoded;
  } catch {
    return url; // Fallback to plain URL if encryption fails
  }
};

const decryptWebhookUrl = (encrypted: string): string => {
  try {
    const decoded = atob(encrypted);
    const [url, key] = decoded.split('|');
    if (key === ENCRYPTION_KEY) {
      return url;
    }
    return encrypted; // Return as-is if decryption fails
  } catch {
    return encrypted; // Return as-is if decryption fails
  }
};

// Enhanced rate limiting with progressive delays
const rateLimitStore = new Map<string, { 
  count: number; 
  lastReset: number; 
  attempts: number; 
  blockUntil?: number; 
}>();

const isRateLimited = (identifier: string, maxRequests = 3, windowMs = 60000): boolean => {
  const now = Date.now();
  const entry = rateLimitStore.get(identifier);
  
  if (!entry || now - entry.lastReset > windowMs) {
    rateLimitStore.set(identifier, { count: 1, lastReset: now, attempts: 1 });
    return false;
  }
  
  // Check if currently blocked
  if (entry.blockUntil && now < entry.blockUntil) {
    console.warn(`Rate limit blocked for identifier: ${identifier}`);
    return true;
  }
  
  entry.attempts++;
  
  if (entry.count >= maxRequests) {
    // Progressive blocking: 1min, 5min, 15min
    const blockDuration = Math.min(60000 * Math.pow(3, entry.attempts - maxRequests), 900000);
    entry.blockUntil = now + blockDuration;
    console.warn(`Rate limit exceeded for identifier: ${identifier}, blocked for ${blockDuration}ms`);
    return true;
  }
  
  entry.count++;
  return false;
};

// Enhanced data sanitization with stricter filtering
const sanitizeData = (data: any): any => {
  if (typeof data === 'string') {
    return data
      .replace(/<script[^>]*>.*?<\/script>/gi, '')
      .replace(/<iframe[^>]*>.*?<\/iframe>/gi, '')
      .replace(/<object[^>]*>.*?<\/object>/gi, '')
      .replace(/<embed[^>]*>.*?<\/embed>/gi, '')
      .replace(/<link[^>]*>/gi, '')
      .replace(/<meta[^>]*>/gi, '')
      .replace(/<style[^>]*>.*?<\/style>/gi, '')
      .replace(/on\w+\s*=/gi, '')
      .replace(/javascript:/gi, '')
      .replace(/data:(?!image\/[a-z]+;base64,)/gi, '')
      .replace(/vbscript:/gi, '')
      .trim()
      .slice(0, 5000); // Limit string length
  }
  
  if (Array.isArray(data)) {
    return data.slice(0, 100).map(sanitizeData); // Limit array size
  }
  
  if (data && typeof data === 'object') {
    const sanitized: any = {};
    let keyCount = 0;
    for (const [key, value] of Object.entries(data)) {
      if (keyCount >= 50) break; // Limit object keys
      
      // Skip dangerous keys
      if (['__proto__', 'constructor', 'prototype', 'eval', 'Function'].includes(key)) {
        continue;
      }
      
      // Sanitize key names
      const cleanKey = key.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 100);
      if (cleanKey.length > 0) {
        sanitized[cleanKey] = sanitizeData(value);
        keyCount++;
      }
    }
    return sanitized;
  }
  
  return data;
};

// Enhanced webhook URL validation with stricter rules
const validateWebhookUrl = (url: string): { isValid: boolean; error?: string } => {
  try {
    const parsedUrl = new URL(url);
    
    // Must be HTTPS
    if (parsedUrl.protocol !== 'https:') {
      return { isValid: false, error: 'Only HTTPS webhooks are allowed' };
    }
    
    // Enhanced trusted domain validation
    const trustedDomains = [
      'make.com',
      'zapier.com',
      'hook.eu1.make.com',
      'hook.eu2.make.com',
      'hook.us1.make.com',
      'hook.us2.make.com',
      'hooks.zapier.com',
      'webhook.site' // For testing only
    ];
    
    const isFromTrustedDomain = trustedDomains.some(domain => 
      parsedUrl.hostname === domain || parsedUrl.hostname.endsWith('.' + domain)
    );
    
    if (!isFromTrustedDomain) {
      return { isValid: false, error: 'Webhook URL must be from a trusted provider' };
    }
    
    // Additional security checks
    if (parsedUrl.pathname.includes('..') || parsedUrl.pathname.includes('//')) {
      return { isValid: false, error: 'Invalid webhook URL path' };
    }
    
    return { isValid: true };
  } catch {
    return { isValid: false, error: 'Invalid webhook URL format' };
  }
};

// Generate enhanced rate limit identifier with more entropy
const generateRateLimitId = (type: string): string => {
  const userAgent = navigator.userAgent.slice(0, 100);
  const language = navigator.language;
  const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const fingerprint = btoa(`${userAgent}-${language}-${timezone}`).slice(0, 16);
  
  return `${type}-${fingerprint}`;
};

export const sendToWebhookSecurely = async (data: any, type: string = 'contact-form') => {
  // Enhanced rate limiting
  const clientId = generateRateLimitId(type);
  if (isRateLimited(clientId, 3, 300000)) { // 3 requests per 5 minutes
    console.warn(`Rate limit exceeded for webhook type: ${type}`);
    return { success: false, error: 'Rate limit exceeded. Please wait before sending another request.' };
  }

  const encryptedWebhookUrl = localStorage.getItem('heavenwraps-webhook-url-encrypted');
  
  if (!encryptedWebhookUrl) {
    return { success: false, error: 'No webhook URL configured' };
  }

  const webhookUrl = decryptWebhookUrl(encryptedWebhookUrl);

  // Enhanced URL validation
  const validation = validateWebhookUrl(webhookUrl);
  if (!validation.isValid) {
    return { success: false, error: validation.error };
  }

  try {
    const sanitizedData = sanitizeData(data);
    
    // Enhanced webhook data with security metadata
    const webhookData: WebhookData = {
      timestamp: new Date().toISOString(),
      source: "Heaven Wraps Website",
      type: type,
      data: {
        ...sanitizedData,
        _security: {
          userAgent: navigator.userAgent.slice(0, 100),
          timestamp: Date.now(),
          version: '2.0',
          checksum: btoa(JSON.stringify(sanitizedData)).slice(0, 16)
        }
      }
    };

    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "HeavenWraps-Webhook/2.0",
        "X-Webhook-Source": "heaven-wraps.nl",
        "X-Security-Version": "2.0"
      },
      mode: "no-cors",
      body: JSON.stringify(webhookData),
    });

    console.log(`Secure webhook sent successfully for type: ${type}`);
    return { success: true };
  } catch (error) {
    console.error(`Secure webhook delivery failed for type: ${type}`, {
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    });
    return { success: false, error: 'Webhook delivery failed' };
  }
};

// Secure webhook URL storage
export const storeWebhookUrlSecurely = (url: string): boolean => {
  const validation = validateWebhookUrl(url);
  if (!validation.isValid) {
    console.error('Invalid webhook URL:', validation.error);
    return false;
  }
  
  const encrypted = encryptWebhookUrl(url);
  localStorage.setItem('heavenwraps-webhook-url-encrypted', encrypted);
  
  // Remove old unencrypted storage
  localStorage.removeItem('heavenwraps-webhook-url');
  
  return true;
};

// Get webhook URL securely
export const getWebhookUrlSecurely = (): string | null => {
  const encrypted = localStorage.getItem('heavenwraps-webhook-url-encrypted');
  if (!encrypted) return null;
  
  return decryptWebhookUrl(encrypted);
};

// Legacy function for backward compatibility
export const sendToWebhook = sendToWebhookSecurely;
