
export interface WebhookData {
  timestamp: string;
  source: string;
  type: string;
  data: any;
}

// Enhanced rate limiting storage with better tracking
const rateLimitStore = new Map<string, { count: number; lastReset: number; attempts: number }>();

const isRateLimited = (identifier: string, maxRequests = 5, windowMs = 60000): boolean => {
  const now = Date.now();
  const entry = rateLimitStore.get(identifier);
  
  if (!entry || now - entry.lastReset > windowMs) {
    rateLimitStore.set(identifier, { count: 1, lastReset: now, attempts: 1 });
    return false;
  }
  
  entry.attempts++;
  
  if (entry.count >= maxRequests) {
    console.warn(`Rate limit exceeded for identifier: ${identifier} (${entry.attempts} attempts)`);
    return true;
  }
  
  entry.count++;
  return false;
};

// Enhanced data sanitization with additional security checks
const sanitizeData = (data: any): any => {
  if (typeof data === 'string') {
    return data
      .replace(/<script[^>]*>.*?<\/script>/gi, '')
      .replace(/<iframe[^>]*>.*?<\/iframe>/gi, '')
      .replace(/<object[^>]*>.*?<\/object>/gi, '')
      .replace(/<embed[^>]*>.*?<\/embed>/gi, '')
      .replace(/<[^>]*>/g, '')
      .replace(/javascript:/gi, '')
      .replace(/on\w+=/gi, '')
      .trim();
  }
  
  if (Array.isArray(data)) {
    return data.map(sanitizeData);
  }
  
  if (data && typeof data === 'object') {
    const sanitized: any = {};
    for (const [key, value] of Object.entries(data)) {
      // Skip potentially dangerous keys
      if (['__proto__', 'constructor', 'prototype'].includes(key)) {
        continue;
      }
      sanitized[key] = sanitizeData(value);
    }
    return sanitized;
  }
  
  return data;
};

// Enhanced webhook URL validation
const validateWebhookUrl = (url: string): { isValid: boolean; error?: string } => {
  try {
    const parsedUrl = new URL(url);
    
    if (!parsedUrl.protocol.startsWith('https')) {
      return { isValid: false, error: 'Only HTTPS webhooks are allowed' };
    }
    
    // Enhanced trusted domain validation
    const trustedDomains = [
      'make.com',
      'zapier.com',
      'hook.eu1.make.com',
      'hook.us1.make.com',
      'hooks.zapier.com',
      'webhook.site', // For testing purposes
    ];
    
    const isFromTrustedDomain = trustedDomains.some(domain => 
      parsedUrl.hostname === domain || parsedUrl.hostname.endsWith('.' + domain)
    );
    
    if (!isFromTrustedDomain) {
      return { isValid: false, error: 'Webhook URL must be from a trusted provider (Make.com, Zapier)' };
    }
    
    return { isValid: true };
  } catch {
    return { isValid: false, error: 'Invalid webhook URL format' };
  }
};

// Generate a more specific rate limit identifier
const generateRateLimitId = (type: string): string => {
  // In a real application with authentication, you would use the user ID
  // For now, we'll use a combination of type and basic browser fingerprinting
  const userAgent = navigator.userAgent;
  const language = navigator.language;
  const fingerprint = btoa(`${userAgent}-${language}`).slice(0, 10);
  
  return `${type}-${fingerprint}`;
};

export const sendToWebhookSecurely = async (data: any, type: string = 'contact-form') => {
  // Enhanced rate limiting with user-specific identifiers
  const clientId = generateRateLimitId(type);
  if (isRateLimited(clientId)) {
    console.warn(`Rate limit exceeded for webhook type: ${type}`);
    return { success: false, error: 'Rate limit exceeded. Please wait before sending another request.' };
  }

  const webhookUrl = localStorage.getItem('heavenwraps-webhook-url');
  
  if (!webhookUrl) {
    return { success: false, error: 'No webhook URL configured' };
  }

  // Enhanced URL validation
  const validation = validateWebhookUrl(webhookUrl);
  if (!validation.isValid) {
    return { success: false, error: validation.error };
  }

  try {
    const sanitizedData = sanitizeData(data);
    
    // Add additional metadata for security tracking
    const webhookData: WebhookData = {
      timestamp: new Date().toISOString(),
      source: "Heaven Wraps Website",
      type: type,
      data: {
        ...sanitizedData,
        _metadata: {
          userAgent: navigator.userAgent.slice(0, 100), // Truncated for privacy
          timestamp: Date.now(),
          version: '1.1'
        }
      }
    };

    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "HeavenWraps-Webhook/1.1"
      },
      mode: "no-cors",
      body: JSON.stringify(webhookData),
    });

    console.log(`Webhook sent successfully for type: ${type}`);
    return { success: true };
  } catch (error) {
    // Enhanced error logging without exposing sensitive information
    console.error(`Webhook delivery failed for type: ${type}`, {
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    });
    return { success: false, error: 'Webhook delivery failed' };
  }
};

// Legacy function for backward compatibility
export const sendToWebhook = sendToWebhookSecurely;
