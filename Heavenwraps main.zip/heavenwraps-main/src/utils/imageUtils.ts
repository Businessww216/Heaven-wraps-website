
// Image URL cache to prevent unnecessary regeneration
const urlCache = new Map<string, string>();

export const createImageUrl = (path: string, forceRefresh = false): string => {
  if (!path) return '';
  
  // Use cached URL if available and not forcing refresh
  if (!forceRefresh && urlCache.has(path)) {
    return urlCache.get(path)!;
  }
  
  const timestamp = forceRefresh ? Date.now() : '';
  const separator = path.includes('?') ? '&' : '?';
  const url = timestamp ? `${path}${separator}t=${timestamp}` : path;
  
  // Cache the URL
  if (!forceRefresh) {
    urlCache.set(path, url);
  }
  
  return url;
};

export const reloadImage = (imgElement: HTMLImageElement): void => {
  if (imgElement && imgElement.src) {
    const baseSrc = imgElement.src.split('?')[0];
    // Clear cache for this image
    urlCache.delete(baseSrc);
    imgElement.src = createImageUrl(baseSrc, true);
  }
};

export const reloadAllImagesOnPage = (): void => {
  // Clear entire URL cache
  urlCache.clear();
  
  const images = document.querySelectorAll('img');
  images.forEach(img => reloadImage(img));
  
  // Also clear service worker cache for images
  if ('caches' in window) {
    caches.keys().then(cacheNames => {
      cacheNames.forEach(cacheName => {
        if (cacheName.includes('heaven-wraps')) {
          caches.open(cacheName).then(cache => {
            cache.keys().then(requests => {
              requests.forEach(request => {
                if (request.url.includes('lovable-uploads')) {
                  cache.delete(request);
                }
              });
            });
          });
        }
      });
    });
  }
};

export const handleImageError = (
  e: React.SyntheticEvent<HTMLImageElement>,
  fallbackSrc?: string
): void => {
  const target = e.target as HTMLImageElement;
  
  // Prevent infinite error loops
  if (target.dataset.errorHandled === 'true') {
    return;
  }
  
  target.dataset.errorHandled = 'true';
  
  if (fallbackSrc && target.src !== fallbackSrc) {
    target.src = fallbackSrc;
  } else {
    // Try reloading with timestamp if no fallback provided
    const baseSrc = target.src.split('?')[0];
    target.src = createImageUrl(baseSrc, true);
  }
};

// Preload images for better performance
export const preloadImages = (imagePaths: string[], priority = false): Promise<void[]> => {
  const loadPromises = imagePaths.map(path => {
    return new Promise<void>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve();
      img.onerror = () => reject(new Error(`Failed to load image: ${path}`));
      img.src = createImageUrl(path);
      
      // Add to cache immediately
      if (priority) {
        img.loading = 'eager';
      }
    });
  });
  
  return Promise.all(loadPromises);
};

// Optimize image loading based on connection speed
export const getOptimalImageQuality = (): 'high' | 'medium' | 'low' => {
  // @ts-ignore - navigator.connection is experimental
  const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  
  if (!connection) return 'high';
  
  const { effectiveType, downlink } = connection;
  
  if (effectiveType === '4g' && downlink > 2) return 'high';
  if (effectiveType === '3g' || (effectiveType === '4g' && downlink <= 2)) return 'medium';
  return 'low';
};

// Lazy loading intersection observer
export const createLazyLoadObserver = (callback: (entry: IntersectionObserverEntry) => void) => {
  const options = {
    root: null,
    rootMargin: '50px',
    threshold: 0.1
  };
  
  return new IntersectionObserver((entries) => {
    entries.forEach(callback);
  }, options);
};
