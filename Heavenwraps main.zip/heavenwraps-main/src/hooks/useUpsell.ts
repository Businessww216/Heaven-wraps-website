
import { useState, useCallback } from 'react';

interface Product {
  title: string;
  price: string;
  image: string;
  description?: string;
}

interface UpsellHook {
  isUpsellOpen: boolean;
  originalProduct: Product | null;
  upsellProduct: Product | null;
  showUpsell: (original: Product, upsell: Product) => void;
  closeUpsell: () => void;
}

export const useUpsell = (): UpsellHook => {
  const [isUpsellOpen, setIsUpsellOpen] = useState(false);
  const [originalProduct, setOriginalProduct] = useState<Product | null>(null);
  const [upsellProduct, setUpsellProduct] = useState<Product | null>(null);

  const showUpsell = useCallback((original: Product, upsell: Product) => {
    setOriginalProduct(original);
    setUpsellProduct(upsell);
    setIsUpsellOpen(true);
  }, []);

  const closeUpsell = useCallback(() => {
    setIsUpsellOpen(false);
    setOriginalProduct(null);
    setUpsellProduct(null);
  }, []);

  return {
    isUpsellOpen,
    originalProduct,
    upsellProduct,
    showUpsell,
    closeUpsell
  };
};
