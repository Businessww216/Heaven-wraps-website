
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { Helmet } from 'react-helmet-async';
import ErrorBoundary from '@/components/ErrorBoundary';
import PerformanceMonitor from '@/components/PerformanceMonitor';
import ImagePreloader from '@/components/ImagePreloader';

// Pages
import Index from '@/pages/Index';
import About from '@/pages/About';
import AssortimentKaleKisten from '@/pages/AssortimentKaleKisten';
import PortfolioGerapteKisten from '@/pages/PortfolioGerapteKisten';
import Portfolio from '@/pages/Portfolio';
import Contact from '@/pages/Contact';
import KistStyler from '@/pages/KistStyler';
import NotFound from '@/pages/NotFound';

// Critical images to preload - force fresh load
const criticalImages = [
  `/lovable-uploads/00dfcf26-7f8c-457c-8317-9d7e89f71388.png?t=${Date.now()}`, // Logo
  `/lovable-uploads/a80785bf-7ba7-48d2-a29f-ae283135a9f9.png?t=${Date.now()}`, // Hero image
];

// Create a stable query client instance
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 10 * 60 * 1000, // 10 minutes (replaces cacheTime)
      retry: 3,
      retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ErrorBoundary>
        <Helmet>
          <title>Heaven Wraps - Persoonlijke Uitvaartkisten</title>
          <meta name="description" content="Unieke, persoonlijke uitvaartkisten met professionele wrapping. Maatwerk afscheid met liefde en respect." />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <link rel="preconnect" href="https://fonts.googleapis.com" />
          <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        </Helmet>
        
        <ImagePreloader images={criticalImages} priority={true} />
        
        <Router>
          <div className="App min-h-screen bg-funeral-offwhite">
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/over-ons" element={<About />} />
              <Route path="/diensten" element={<AssortimentKaleKisten />} />
              <Route path="/portfolio-gerapte-kisten" element={<PortfolioGerapteKisten />} />
              <Route path="/portfolio" element={<Portfolio />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/kist-styler" element={<KistStyler />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>
        </Router>
        
        <PerformanceMonitor />
        <Toaster />
      </ErrorBoundary>
    </QueryClientProvider>
  );
}

export default App;
