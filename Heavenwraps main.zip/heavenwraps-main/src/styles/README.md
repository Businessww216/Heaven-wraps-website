
# Styles Directory

This directory contains modular CSS files organized by purpose:

- `base.css` - Base styles, CSS variables, and Tailwind imports
- `components.css` - Component-specific styles and layouts
- `animations.css` - Animation keyframes and utilities
- `effects.css` - Visual effects like particles and hover states
- `utilities.css` - Utility classes and performance optimizations

All files are imported in the main `index.css` file.
