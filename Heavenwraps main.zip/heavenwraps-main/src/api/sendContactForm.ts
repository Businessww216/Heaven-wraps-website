
/**
 * Enhanced helper to send contact form data to the Supabase Edge Function
 * @param data - Contact form data with validation
 */
export async function sendContactForm(data: {
  name: string;
  email: string;
  phone?: string;
  message: string;
  service?: string;
}) {
  console.log('sendContactForm called with data:', data);
  
  // Client-side validation before sending
  if (!data.name.trim() || !data.email.trim() || !data.message.trim()) {
    throw new Error('Required fields are missing');
  }

  // Enhanced email format validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(data.email)) {
    throw new Error('Invalid email format');
  }

  // Sanitize input data to prevent XSS
  const sanitizeInput = (input: string): string => {
    return input
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\//g, '&#x2F;')
      .trim();
  };

  try {
    console.log('Making fetch request to edge function...');
    
    // Use the Supabase client configuration instead of hardcoded values
    const supabaseUrl = "https://sjsydmahspifegzrthss.supabase.co";
    const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNqc3lkbWFoc3BpZmVnenJ0aHNzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAwMTU3NjQsImV4cCI6MjA2NTU5MTc2NH0.Cgy0HLEb19axJt6fk5vCAP1T74XzYRKgaFKqi9xie-k";
    
    const response = await fetch(`${supabaseUrl}/functions/v1/send-contact-email`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${supabaseAnonKey}`,
        "X-Client-Version": "1.2",
        "X-Requested-With": "XMLHttpRequest" // CSRF protection
      },
      body: JSON.stringify({
        name: sanitizeInput(data.name),
        email: sanitizeInput(data.email.toLowerCase()),
        phone: data.phone ? sanitizeInput(data.phone) : undefined,
        message: sanitizeInput(data.message),
        service: data.service,
        timestamp: new Date().toISOString(),
        // Add CSRF-like token
        clientFingerprint: btoa(`${navigator.userAgent}-${Date.now()}`).slice(0, 16)
      }),
    });

    console.log('Response status:', response.status);
    console.log('Response ok:', response.ok);

    if (!response.ok) {
      let errorMessage = 'Failed to send contact form';
      try {
        const errorData = await response.json();
        console.log('Error response data:', errorData);
        errorMessage = errorData.message || errorMessage;
      } catch {
        console.log('Could not parse error response as JSON');
      }
      throw new Error(errorMessage);
    }

    const result = await response.json();
    console.log('Success response:', result);
    return result;
  } catch (error) {
    console.error('Contact form submission failed:', error);
    throw error;
  }
}
