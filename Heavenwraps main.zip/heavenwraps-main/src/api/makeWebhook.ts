
/**
 * Helper to send contact form data to the Make.com webhook endpoint
 */
export async function sendToMakeWebhook(data: {
  name: string;
  email: string;
  phone?: string;
  message: string;
  service?: string;
}) {
  console.log('sendToMakeWebhook called with data:', data);
  
  try {
    console.log('Sending to Make.com webhook endpoint...');
    const response = await fetch("/functions/v1/make-webhook", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Client-Version": "1.0"
      },
      body: JSON.stringify({
        name: data.name.trim(),
        email: data.email.trim().toLowerCase(),
        phone: data.phone?.trim(),
        message: data.message.trim(),
        service: data.service,
        timestamp: new Date().toISOString()
      }),
    });

    console.log('Make.com webhook response status:', response.status);

    if (!response.ok) {
      let errorMessage = 'Failed to send to Make.com webhook';
      try {
        const errorData = await response.json();
        console.log('Make.com webhook error response:', errorData);
        errorMessage = errorData.message || errorMessage;
      } catch {
        console.log('Could not parse Make.com webhook error response');
      }
      throw new Error(errorMessage);
    }

    const result = await response.json();
    console.log('Make.com webhook success response:', result);
    return result;
  } catch (error) {
    console.error('Make.com webhook submission failed:', error);
    throw error;
  }
}
