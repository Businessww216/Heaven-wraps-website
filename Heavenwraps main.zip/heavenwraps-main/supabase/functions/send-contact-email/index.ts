
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-requested-with",
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "X-XSS-Protection": "1; mode=block",
  "Referrer-Policy": "strict-origin-when-cross-origin",
};

interface ContactFormData {
  name: string;
  email: string;
  phone?: string;
  message: string;
  service?: string;
  clientFingerprint?: string;
}

// Enhanced rate limiting with IP tracking
const rateLimitStore = new Map<string, { count: number; lastReset: number; blocked: boolean }>();

const isRateLimited = (ip: string, maxRequests = 5, windowMs = 300000): boolean => {
  const now = Date.now();
  const entry = rateLimitStore.get(ip);
  
  if (!entry || now - entry.lastReset > windowMs) {
    rateLimitStore.set(ip, { count: 1, lastReset: now, blocked: false });
    return false;
  }
  
  if (entry.blocked) {
    return true;
  }
  
  if (entry.count >= maxRequests) {
    entry.blocked = true;
    // Auto-unblock after additional window
    setTimeout(() => {
      const currentEntry = rateLimitStore.get(ip);
      if (currentEntry) {
        currentEntry.blocked = false;
        currentEntry.count = 0;
        currentEntry.lastReset = Date.now();
      }
    }, windowMs);
    return true;
  }
  
  entry.count++;
  return false;
};

// Enhanced input validation and sanitization
const validateContactData = (data: any): ContactFormData => {
  // Type checking
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid request data');
  }

  // Enhanced HTML escaping function
  const escapeHtml = (text: string): string => {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\//g, '&#x2F;');
  };

  // Name validation
  if (!data.name || typeof data.name !== 'string' || data.name.length < 2 || data.name.length > 100) {
    throw new Error('Invalid name: must be 2-100 characters');
  }
  
  // Enhanced email validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  if (!data.email || typeof data.email !== 'string' || !emailRegex.test(data.email) || data.email.length > 254) {
    throw new Error('Invalid email format');
  }
  
  // Message validation
  if (!data.message || typeof data.message !== 'string' || data.message.length < 10 || data.message.length > 2000) {
    throw new Error('Invalid message: must be 10-2000 characters');
  }
  
  // Phone validation (optional)
  if (data.phone && (typeof data.phone !== 'string' || data.phone.length > 20)) {
    throw new Error('Invalid phone number');
  }

  // Service validation
  if (data.service && !['basic', 'custom'].includes(data.service)) {
    throw new Error('Invalid service type');
  }
  
  return {
    name: escapeHtml(data.name.trim()),
    email: escapeHtml(data.email.trim().toLowerCase()),
    phone: data.phone ? escapeHtml(data.phone.trim()) : undefined,
    message: escapeHtml(data.message.trim()),
    service: data.service,
    clientFingerprint: data.clientFingerprint
  };
};

// Enhanced CSRF-like protection
const validateRequest = (req: Request, data: any): boolean => {
  // Check required headers
  const requestedWith = req.headers.get("x-requested-with");
  if (requestedWith !== "XMLHttpRequest") {
    console.warn("Missing X-Requested-With header");
    return false;
  }

  // Validate client fingerprint if provided
  if (data.clientFingerprint) {
    try {
      const decoded = atob(data.clientFingerprint);
      if (!decoded || decoded.length < 10) {
        console.warn("Invalid client fingerprint");
        return false;
      }
    } catch {
      console.warn("Failed to decode client fingerprint");
      return false;
    }
  }

  return true;
};

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response("Method not allowed", { 
      status: 405, 
      headers: corsHeaders 
    });
  }

  try {
    // Get client IP for rate limiting
    const clientIP = req.headers.get("x-forwarded-for")?.split(',')[0]?.trim() || 
                     req.headers.get("x-real-ip") || 
                     "unknown";
    
    // Enhanced rate limiting
    if (isRateLimited(clientIP)) {
      console.log(`Rate limit exceeded for IP: ${clientIP}`);
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
        {
          status: 429,
          headers: {
            "Content-Type": "application/json",
            "Retry-After": "300",
            ...corsHeaders,
          },
        }
      );
    }

    const requestData = await req.json();
    console.log("Contact form submission received");
    
    // Enhanced request validation
    if (!validateRequest(req, requestData)) {
      return new Response(
        JSON.stringify({ error: "Invalid request" }),
        {
          status: 400,
          headers: {
            "Content-Type": "application/json",
            ...corsHeaders,
          },
        }
      );
    }
    
    // Validate and sanitize input data
    const validatedData = validateContactData(requestData);
    
    // Send confirmation email if Resend is configured
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (resendApiKey) {
      try {
        await resend.emails.send({
          from: "Heaven Wraps <noreply@heavenwraps.nl>",
          to: ["info@heaven-wraps.nl"],
          subject: `Nieuw contact formulier: ${validatedData.name}`,
          html: `
            <h2>Nieuw contact formulier ontvangen</h2>
            <p><strong>Naam:</strong> ${validatedData.name}</p>
            <p><strong>E-mail:</strong> ${validatedData.email}</p>
            ${validatedData.phone ? `<p><strong>Telefoon:</strong> ${validatedData.phone}</p>` : ''}
            ${validatedData.service ? `<p><strong>Dienst:</strong> ${validatedData.service}</p>` : ''}
            <p><strong>Bericht:</strong></p>
            <p>${validatedData.message.replace(/\n/g, '<br>')}</p>
            <hr>
            <p><small>Verzonden op: ${new Date().toLocaleString('nl-NL')}</small></p>
          `,
        });
        console.log("Email sent successfully to info@heaven-wraps.nl");
      } catch (emailError) {
        console.error("Failed to send email:", emailError);
        // Don't fail the request if email sending fails
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Contact form submitted successfully",
        timestamp: new Date().toISOString()
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );

  } catch (error: any) {
    console.error("Error in send-contact-email function:", error);
    
    return new Response(
      JSON.stringify({ 
        error: "Failed to process contact form",
        message: error.message 
      }),
      {
        status: 400,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  }
};

serve(handler);
