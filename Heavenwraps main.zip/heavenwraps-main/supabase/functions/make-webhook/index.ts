
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface WebhookData {
  name: string;
  email: string;
  phone?: string;
  message: string;
  service?: string;
  timestamp: string;
  source: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response("Method not allowed", { 
      status: 405, 
      headers: corsHeaders 
    });
  }

  try {
    const requestData = await req.json();
    console.log("Make.com webhook endpoint called with data:", requestData);

    // Validate required fields
    if (!requestData.name || !requestData.email || !requestData.message) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: name, email, message" }),
        {
          status: 400,
          headers: {
            "Content-Type": "application/json",
            ...corsHeaders,
          },
        }
      );
    }

    // Prepare webhook data for Make.com
    const webhookData: WebhookData = {
      name: requestData.name,
      email: requestData.email,
      phone: requestData.phone || "",
      message: requestData.message,
      service: requestData.service || "",
      timestamp: new Date().toISOString(),
      source: "Heaven Wraps Contact Form"
    };

    console.log("Prepared webhook data:", webhookData);

    // Return the data that Make.com will receive
    return new Response(
      JSON.stringify({
        success: true,
        data: webhookData,
        message: "Data processed successfully for Make.com"
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );

  } catch (error: any) {
    console.error("Error in make-webhook function:", error);
    
    return new Response(
      JSON.stringify({ 
        error: "Failed to process webhook data",
        message: error.message 
      }),
      {
        status: 500,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  }
};

serve(handler);
